#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <stdexcept> // Untuk std::runtime_error
#include <sstream>
#include <algorithm> // Untuk std::max, std::min
#include <cctype>    // Untuk isalpha, isdigit, isspace, isalnum

// C++11 Standard

// --- Konfigurasi dan Konstanta ---
const int TEMP_REGISTER_POOL_SIZE = 8; // Jumlah register $t0-$t7
const int WORD_SIZE_BYTES = 4;
const std::string MIPS_HELPER_REG_1 = "$t8"; // Register bantu untuk MIPS
const std::string MIPS_HELPER_REG_2 = "$t9"; // Register bantu lainnya

// --- Definisi Tipe Data ---

// Tipe Token yang Ditingkatkan dengan enum class
enum class LexTokenType {
    // Keywords
    KEYWORD_CONST, KEYWORD_INT, KEYWORD_BREAK, KEYWORD_CONTINUE, KEYWORD_IF, KEYWORD_ELSE,
    KEYWORD_WHILE, KEYWORD_RETURN, KEYWORD_VOID, KEYWORD_MAIN, KEYWORD_GETINT, KEYWORD_PRINTF,
    // Identifier & Literals
    IDENTIFIER, INTEGER_LITERAL, STRING_LITERAL,
    // Simbol & Operator
    OP_NOT_EQUAL, OP_NOT, OP_AND, OP_OR, OP_PLUS, OP_MINUS, OP_MULTIPLY, OP_DIVIDE, OP_MODULO,
    OP_LESS, OP_LESS_EQUAL, OP_GREATER, OP_GREATER_EQUAL, OP_EQUAL, OP_ASSIGN,
    SYM_SEMICOLON, SYM_COMMA, SYM_LPAREN, SYM_RPAREN, SYM_LBRACKET, SYM_RBRACKET, SYM_LBRACE, SYM_RBRACE,
    // Kontrol
    END_OF_INPUT, UNKNOWN_TOKEN
};

// Informasi Token
struct LexToken {
    LexTokenType type;
    std::string lexeme; // Teks aktual dari token
    // Bisa ditambahkan info baris/kolom untuk error yang lebih baik

    LexToken(LexTokenType t = LexTokenType::UNKNOWN_TOKEN, std::string l = "") : type(t), lexeme(std::move(l)) {}
};

// Operasi dalam Intermediate Representation (IR)
enum class IntermediateOpCode {
    // Aritmatika & Logika
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD, OP_NEGATE, OP_LOGICAL_NOT, OP_LOGICAL_AND, OP_LOGICAL_OR,
    // Perbandingan
    OP_CMP_LESS, OP_CMP_LESS_EQUAL, OP_CMP_GREATER, OP_CMP_GREATER_EQUAL, OP_CMP_EQUAL, OP_CMP_NOT_EQUAL,
    // Memori
    LOAD_IMMEDIATE, LOAD_ADDRESS, LOAD_FROM_MEMORY, STORE_TO_MEMORY,
    // Aliran Kontrol
    DEFINE_LABEL, JUMP_UNCONDITIONAL, BRANCH_IF_EQUAL, BRANCH_IF_NOT_EQUAL, BRANCH_IF_ZERO, BRANCH_IF_NOT_ZERO,
    // Panggilan & Pengembalian Fungsi
    CALL_FUNCTION, RETURN_VALUE, RETURN_VOID, PUSH_ARGUMENT, POP_ARGUMENTS_FROM_STACK,
    // Prolog & Epilog Fungsi (bisa lebih detail jika diperlukan)
    FUNCTION_PROLOGUE_MARKER, FUNCTION_EPILOGUE_MARKER, JUMP_TO_REGISTER,
    // Input/Output
    SYSTEM_GETINT, SYSTEM_PRINT_STRING, SYSTEM_PRINT_INT,
    // Khusus / Meta
    NO_OPERATION, // Placeholder, misal untuk titik sisipan prologue

    // Pembantu khusus MIPS
    MIPS_DIRECT_MOVE,
    MIPS_DIRECT_SYSCALL,
    MIPS_DIRECT_LOAD_ADDRESS, // LA
    MIPS_DIRECT_ADDIU,        // ADDIU
    MIPS_DIRECT_LW,           // LW  <--- GANTI NAMA INI (jika sebelumnya MIPS_DIRECT_LOAD_WORD)
    MIPS_DIRECT_SW            // SW  <--- GANTI NAMA INI (jika sebelumnya MIPS_DIRECT_STORE_WORD)
};

// Operand dalam IR
struct IntermediateOperand {
    enum class Type {
        UNSPECIFIED, TEMPORARY_REGISTER, GLOBAL_VARIABLE_LABEL, STACK_LOCAL_ADDRESS,
        IMMEDIATE_VALUE, CODE_LABEL, STRING_DATA_LABEL, MIPS_HARDWARE_REGISTER
    };
    Type type;
    std::string representation; // Nama reg ('t0'), nama var ('x'), alamat ('12($sp)'), immediate ('100'), label ('L1')
    int numeric_value_or_offset; // Untuk immediate atau offset stack

    IntermediateOperand(Type t = Type::UNSPECIFIED, std::string r = "", int val_or_off = 0)
        : type(t), representation(std::move(r)), numeric_value_or_offset(val_or_off) {}

    static IntermediateOperand create_temp_reg(int id) { return IntermediateOperand(Type::TEMPORARY_REGISTER, "t" + std::to_string(id)); }
    static IntermediateOperand create_mips_reg(const std::string& name) { return IntermediateOperand(Type::MIPS_HARDWARE_REGISTER, name); }
    static IntermediateOperand create_global_var(const std::string& name) { return IntermediateOperand(Type::GLOBAL_VARIABLE_LABEL, name); }
    static IntermediateOperand create_stack_local(int offset) { return IntermediateOperand(Type::STACK_LOCAL_ADDRESS, std::to_string(offset) + "($sp)", offset); }
    static IntermediateOperand create_immediate(int val) { return IntermediateOperand(Type::IMMEDIATE_VALUE, std::to_string(val), val); }
    static IntermediateOperand create_immediate_from_string(const std::string& val_str) {
        try { return IntermediateOperand(Type::IMMEDIATE_VALUE, val_str, std::stoi(val_str)); }
        catch (...) { /* Handle error atau biarkan apa adanya jika bukan int */ return IntermediateOperand(Type::IMMEDIATE_VALUE, val_str, 0); }
    }
    static IntermediateOperand create_code_label(const std::string& name) { return IntermediateOperand(Type::CODE_LABEL, name); }
    static IntermediateOperand create_string_label(const std::string& name) { return IntermediateOperand(Type::STRING_DATA_LABEL, name); }
    static IntermediateOperand create_unspecified() { return IntermediateOperand(Type::UNSPECIFIED, ""); }
};

// Instruksi IR
struct IntermediateInstruction {
    IntermediateOpCode operation;
    IntermediateOperand arg1;
    IntermediateOperand arg2;
    IntermediateOperand result_or_target; // Bisa hasil operasi atau target branch/jump

    IntermediateInstruction(IntermediateOpCode op,
                            IntermediateOperand a1 = IntermediateOperand::create_unspecified(),
                            IntermediateOperand a2 = IntermediateOperand::create_unspecified(),
                            IntermediateOperand res_tgt = IntermediateOperand::create_unspecified())
        : operation(op), arg1(std::move(a1)), arg2(std::move(a2)), result_or_target(std::move(res_tgt)) {}
};

// Informasi Simbol
struct SymbolAttributes {
    std::string identifier_name;
    std::string data_type_name; // "int", "void", "const int", "int[]", "const int[]"
    int memory_offset;          // Offset stack untuk lokal, atau 0 untuk global/fungsi
    bool is_globally_scoped;
    bool is_value_constant;
    bool is_function_symbol;
    int num_array_elements; // Ukuran array, 1 untuk skalar
    std::string initial_value_representation; // Nilai tunggal untuk const/global skalar, "{v1,v2..}" untuk array global
    std::vector<std::string> constant_array_init_values; // Nilai untuk array const

    SymbolAttributes() : memory_offset(0), is_globally_scoped(true), is_value_constant(false),
                         is_function_symbol(false), num_array_elements(1) {}

    SymbolAttributes(std::string name, std::string type, int offset, bool is_const, bool is_func, bool is_global, int arr_size = 1)
        : identifier_name(std::move(name)), data_type_name(std::move(type)), memory_offset(offset),
          is_globally_scoped(is_global), is_value_constant(is_const), is_function_symbol(is_func),
          num_array_elements(arr_size) {}

    bool is_array_type() const { return num_array_elements > 1 || data_type_name.find("[]") != std::string::npos; }
};

// Scope dalam tumpukan tabel simbol
using SymbolTableScope = std::unordered_map<std::string, SymbolAttributes>;

// Wrapper hasil untuk find_symbol (pengganti std::optional)
struct FoundSymbol {
    bool success;
    SymbolAttributes attributes; // Salinan simbol jika ditemukan

    FoundSymbol(bool s = false, SymbolAttributes attrs = SymbolAttributes()) : success(s), attributes(std::move(attrs)) {}
};

// Wrapper hasil untuk evaluate_constant_identifier
struct EvaluatedConstant {
    bool success;
    int value;

    EvaluatedConstant(bool s = false, int v = 0) : success(s), value(v) {}
};


// --- Kelas Compiler Utama ---
class SysYCompiler {
public:
    SysYCompiler() :
        m_current_token_idx(0),
        m_current_local_stack_offset(0),
        m_temp_reg_alloc_counter(0),
        m_unique_label_counter(0),
        m_string_data_counter(0),
        m_current_function_return_label(""),
        m_current_spill_area_offset(0),
        m_max_spill_area_needed_for_func(0)
    {
        initialize_lexical_maps();
    }

    bool process_source(const std::string& source_code_text, std::ostream& mips_output_stream) {
        m_source_text = source_code_text;
        m_current_char_pos = 0;
        m_lex_tokens.clear();
        m_current_token_idx = 0;
        m_symbol_table_manager.clear();
        m_current_local_stack_offset = 0;
        m_ir_code_sequence.clear();
        m_temp_reg_alloc_counter = 0;
        m_unique_label_counter = 0;
        m_string_data_counter = 0;
        m_data_segment_literals.clear();
        m_current_function_return_label = "";
        m_loop_continue_label_stack.clear();
        m_loop_break_label_stack.clear();
        reset_function_spill_tracking();

        try {
            // 1. Analisis Leksikal
            perform_lexical_analysis();

            // 2. Analisis Sintaks & Generasi IR
            parse_top_level_constructs();

            // 3. Generasi Kode MIPS
            translate_ir_to_mips(mips_output_stream);

        } catch (const std::runtime_error& e) {
            std::cerr << "Compilation Error: " << e.what() << std::endl;
            return false;
        } catch (...) {
             std::cerr << "An unexpected error occurred during compilation." << std::endl;
             return false;
        }
        return true;
    }

private:
    // --- Variabel State Internal ---
    std::string m_source_text;
    size_t m_current_char_pos;
    std::vector<LexToken> m_lex_tokens;
    size_t m_current_token_idx;

    std::vector<SymbolTableScope> m_symbol_table_manager; // Tumpukan scope
    int m_current_local_stack_offset; // Offset stack berikutnya dalam scope fungsi

    std::vector<IntermediateInstruction> m_ir_code_sequence;
    int m_temp_reg_alloc_counter;
    int m_unique_label_counter;
    int m_string_data_counter;
    std::vector<std::pair<std::string, std::string>> m_data_segment_literals; // label -> konten

    // Konteks Fungsi/Loop
    std::string m_current_function_return_label;
    std::vector<std::string> m_loop_continue_label_stack;
    std::vector<std::string> m_loop_break_label_stack;

    // Manajemen Spill dalam Fungsi
    int m_current_spill_area_offset; // Offset tambahan saat ini untuk spill
    int m_max_spill_area_needed_for_func; // Ruang spill maks yang dibutuhkan fungsi saat ini

    // Pemetaan Leksikal
    std::unordered_map<std::string, LexTokenType> m_keyword_to_type_map;
    std::unordered_map<std::string, LexTokenType> m_symbol_to_type_map;

    // --- Metode Internal ---

    // -- Analisis Leksikal --
    void initialize_lexical_maps() {
        m_keyword_to_type_map = {
            {"const", LexTokenType::KEYWORD_CONST}, {"int", LexTokenType::KEYWORD_INT},
            {"break", LexTokenType::KEYWORD_BREAK}, {"continue", LexTokenType::KEYWORD_CONTINUE},
            {"if", LexTokenType::KEYWORD_IF}, {"else", LexTokenType::KEYWORD_ELSE},
            {"while", LexTokenType::KEYWORD_WHILE}, {"return", LexTokenType::KEYWORD_RETURN},
            {"void", LexTokenType::KEYWORD_VOID}, {"main", LexTokenType::KEYWORD_MAIN},
            {"getint", LexTokenType::KEYWORD_GETINT}, {"printf", LexTokenType::KEYWORD_PRINTF}
        };
        m_symbol_to_type_map = {
            {"!=", LexTokenType::OP_NOT_EQUAL}, {"!", LexTokenType::OP_NOT}, {"&&", LexTokenType::OP_AND},
            {"||", LexTokenType::OP_OR}, {"+", LexTokenType::OP_PLUS}, {"-", LexTokenType::OP_MINUS},
            {"*", LexTokenType::OP_MULTIPLY}, {"/", LexTokenType::OP_DIVIDE}, {"%", LexTokenType::OP_MODULO},
            {"<", LexTokenType::OP_LESS}, {"<=", LexTokenType::OP_LESS_EQUAL}, {">", LexTokenType::OP_GREATER},
            {">=", LexTokenType::OP_GREATER_EQUAL}, {"==", LexTokenType::OP_EQUAL}, {"=", LexTokenType::OP_ASSIGN},
            {";", LexTokenType::SYM_SEMICOLON}, {",", LexTokenType::SYM_COMMA}, {"(", LexTokenType::SYM_LPAREN},
            {")", LexTokenType::SYM_RPAREN}, {"[", LexTokenType::SYM_LBRACKET}, {"]", LexTokenType::SYM_RBRACKET},
            {"{", LexTokenType::SYM_LBRACE}, {"}", LexTokenType::SYM_RBRACE}
        };
    }

    void advance_past_whitespace_and_comments() {
        while (m_current_char_pos < m_source_text.length()) {
            if (std::isspace(m_source_text[m_current_char_pos])) {
                m_current_char_pos++;
            } else if (m_current_char_pos + 1 < m_source_text.length() && m_source_text[m_current_char_pos] == '/') {
                if (m_source_text[m_current_char_pos + 1] == '/') { // Komentar satu baris
                    m_current_char_pos += 2;
                    while (m_current_char_pos < m_source_text.length() && m_source_text[m_current_char_pos] != '\n') {
                        m_current_char_pos++;
                    }
                } else if (m_source_text[m_current_char_pos + 1] == '*') { // Komentar multi-baris
                    m_current_char_pos += 2;
                    while (m_current_char_pos + 1 < m_source_text.length()) {
                        if (m_source_text[m_current_char_pos] == '*' && m_source_text[m_current_char_pos + 1] == '/') {
                            m_current_char_pos += 2;
                            goto next_iteration_of_skipping;
                        }
                        m_current_char_pos++;
                    }
                    trigger_compilation_error("Unterminated multi-line comment found");
                    m_current_char_pos = m_source_text.length(); // Hindari infinite loop
                } else {
                    break; // '/' tunggal adalah bagian dari operator, ditangani nanti
                }
            } else {
                break; // Bukan whitespace atau awal komentar
            }
            next_iteration_of_skipping:;
        }
    }

    LexToken extract_next_token() {
        advance_past_whitespace_and_comments();
        if (m_current_char_pos >= m_source_text.length()) return LexToken(LexTokenType::END_OF_INPUT, "");

        // Coba cocokkan operator dua karakter dulu
        if (m_current_char_pos + 1 < m_source_text.length()) {
            std::string potential_two_char_op = m_source_text.substr(m_current_char_pos, 2);
            if (m_symbol_to_type_map.count(potential_two_char_op)) {
                m_current_char_pos += 2;
                return LexToken(m_symbol_to_type_map[potential_two_char_op], potential_two_char_op);
            }
        }
        // Coba cocokkan operator satu karakter
        std::string potential_one_char_op = m_source_text.substr(m_current_char_pos, 1);
        if (m_symbol_to_type_map.count(potential_one_char_op)) {
            m_current_char_pos += 1;
            return LexToken(m_symbol_to_type_map[potential_one_char_op], potential_one_char_op);
        }

        // String literal
        if (m_source_text[m_current_char_pos] == '"') {
            std::string literal_value_with_quotes = "\"";
            m_current_char_pos++; // Lewati " pembuka
            bool in_escape_sequence = false;
            while (m_current_char_pos < m_source_text.length()) {
                char current_c = m_source_text[m_current_char_pos];
                literal_value_with_quotes += current_c;
                if (in_escape_sequence) {
                    in_escape_sequence = false;
                } else if (current_c == '\\') {
                    in_escape_sequence = true;
                } else if (current_c == '"') {
                    m_current_char_pos++;
                    return LexToken(LexTokenType::STRING_LITERAL, literal_value_with_quotes);
                }
                m_current_char_pos++;
            }
            trigger_compilation_error("Unterminated string literal encountered");
            return LexToken(LexTokenType::UNKNOWN_TOKEN, literal_value_with_quotes); // Kembalikan apa yang ada
        }

        // Identifier dan Keyword
        if (std::isalpha(m_source_text[m_current_char_pos]) || m_source_text[m_current_char_pos] == '_') {
            size_t start_index = m_current_char_pos++;
            while (m_current_char_pos < m_source_text.length() && (std::isalnum(m_source_text[m_current_char_pos]) || m_source_text[m_current_char_pos] == '_')) {
                m_current_char_pos++;
            }
            std::string word = m_source_text.substr(start_index, m_current_char_pos - start_index);
            if (m_keyword_to_type_map.count(word)) {
                return LexToken(m_keyword_to_type_map[word], word);
            } else {
                return LexToken(LexTokenType::IDENTIFIER, word);
            }
        }

        // Konstanta Integer
        if (std::isdigit(m_source_text[m_current_char_pos])) {
            size_t start_index = m_current_char_pos++;
            while (m_current_char_pos < m_source_text.length() && std::isdigit(m_source_text[m_current_char_pos])) {
                m_current_char_pos++;
            }
            std::string number_str = m_source_text.substr(start_index, m_current_char_pos - start_index);
            return LexToken(LexTokenType::INTEGER_LITERAL, number_str);
        }

        // Jika tidak ada yang cocok
        trigger_compilation_error("Unrecognized character in source: " + std::string(1, m_source_text[m_current_char_pos]));
        m_current_char_pos++; // Maju untuk menghindari loop tak terbatas pada error
        return LexToken(LexTokenType::UNKNOWN_TOKEN, m_source_text.substr(m_current_char_pos - 1, 1));
    }

    void perform_lexical_analysis() {
        m_lex_tokens.clear();
        LexToken current_lex_token;
        do {
            current_lex_token = extract_next_token();
            if (current_lex_token.type != LexTokenType::UNKNOWN_TOKEN || current_lex_token.type == LexTokenType::END_OF_INPUT) {
                m_lex_tokens.push_back(current_lex_token);
            } else {
                // Error sudah dilaporkan oleh extract_next_token, hentikan lexing.
                trigger_compilation_error("Lexical analysis failed due to unrecognized token.");
                return; // Hentikan analisis lebih lanjut jika ada token tidak dikenal
            }
        } while (current_lex_token.type != LexTokenType::END_OF_INPUT);

        // Pastikan ada token END_OF_INPUT di akhir jika lexing berhasil tanpa error sebelumnya
        if (m_lex_tokens.empty() || m_lex_tokens.back().type != LexTokenType::END_OF_INPUT) {
            m_lex_tokens.push_back(LexToken(LexTokenType::END_OF_INPUT, ""));
        }
    }


    // -- Pembantu Parser --
    LexToken look_ahead(int offset = 0) const {
        size_t target_idx = m_current_token_idx + offset;
        if (target_idx < m_lex_tokens.size()) {
            return m_lex_tokens[target_idx];
        }
        return LexToken(LexTokenType::END_OF_INPUT, ""); // Kembalikan EOF jika melewati akhir
    }

    LexToken consume_current_token() {
        if (m_current_token_idx < m_lex_tokens.size()) {
            return m_lex_tokens[m_current_token_idx++];
        }
        // Seharusnya tidak terjadi jika EOF diperiksa
        return LexToken(LexTokenType::END_OF_INPUT, "");
    }

    LexToken expect_token_type(LexTokenType expected) {
        LexToken current = look_ahead();
        if (current.type == expected) {
            return consume_current_token();
        } else {
            std::stringstream error_msg_builder;
            error_msg_builder << "Parser Error: Expected token type " << static_cast<int>(expected)
                              << ", but received " << static_cast<int>(current.type)
                              << " (Lexeme: '" << current.lexeme << "') at token index " << m_current_token_idx;
            trigger_compilation_error(error_msg_builder.str());
            return LexToken(LexTokenType::UNKNOWN_TOKEN, ""); // Untuk kasus error, kembalikan token dummy
        }
    }

    bool attempt_match_and_consume(LexTokenType type_to_match) {
        if (look_ahead().type == type_to_match) {
            consume_current_token();
            return true;
        }
        return false;
    }

    void trigger_compilation_error(const std::string& error_detail) {
        // Bisa ditambahkan info baris/kolom jika dilacak oleh lexer
        // Untuk sekarang, runtime_error akan menghentikan kompilasi.
        throw std::runtime_error(error_detail);
    }

    // -- Tabel Simbol & Scope --
    void open_new_scope(bool is_for_function = true) {
        m_symbol_table_manager.push_back(SymbolTableScope());
        if (is_for_function) {
            m_current_local_stack_offset = 0; // Reset offset untuk lokal/parameter fungsi
            reset_function_spill_tracking();   // Reset pelacakan spill untuk fungsi baru
        }
    }

    void close_current_scope() {
        if (!m_symbol_table_manager.empty()) {
            m_symbol_table_manager.pop_back();
        } else {
            trigger_compilation_error("Internal Error: Attempted to close a non-existent scope.");
        }
    }

    SymbolAttributes& add_symbol_to_current_scope(const std::string& id_name, const std::string& type_str, bool is_const_val, bool is_func, int num_elements = 1) {
        if (m_symbol_table_manager.empty()) {
            trigger_compilation_error("Internal Error: Symbol declaration outside any scope.");
        }
        SymbolTableScope& active_scope = m_symbol_table_manager.back();
        if (active_scope.count(id_name)) {
            trigger_compilation_error("Semantic Error: Symbol '" + id_name + "' redeclared in the same scope.");
        }

        bool is_global_context = (m_symbol_table_manager.size() == 1);
        int allocated_address = 0;
        if (!is_global_context && !is_func) { // Lokal non-fungsi
            allocated_address = m_current_local_stack_offset;
            m_current_local_stack_offset += num_elements * WORD_SIZE_BYTES;
        }

        active_scope[id_name] = SymbolAttributes(id_name, type_str, allocated_address, is_const_val, is_func, is_global_context, num_elements);
        return active_scope.at(id_name); // Kembalikan referensi ke yang baru ditambahkan
    }

    FoundSymbol search_for_symbol(const std::string& id_name) const {
        // Cari dari scope saat ini mundur ke scope global
        for (auto scope_iter = m_symbol_table_manager.rbegin(); scope_iter != m_symbol_table_manager.rend(); ++scope_iter) {
            const auto& current_scope_map = *scope_iter;
            auto symbol_iter = current_scope_map.find(id_name);
            if (symbol_iter != current_scope_map.end()) {
                return FoundSymbol(true, symbol_iter->second); // Kembalikan salinan
            }
        }
        return FoundSymbol(false, SymbolAttributes()); // Tidak ditemukan
    }

    IntermediateOperand get_address_operand_for_symbol(const std::string& id_name) {
         FoundSymbol search_res = search_for_symbol(id_name);
         if (!search_res.success) {
             trigger_compilation_error("Semantic Error: Undeclared identifier '" + id_name + "' used.");
             // Baris di bawah ini tidak akan tercapai karena trigger_compilation_error melempar exception
             return IntermediateOperand::create_unspecified();
         }
         const SymbolAttributes& sym_attrs = search_res.attributes;
         if (sym_attrs.is_globally_scoped) {
             // Untuk global atau fungsi, gunakan nama sebagai label alamat
             return IntermediateOperand::create_global_var(sym_attrs.identifier_name);
         } else {
             // Untuk lokal, gunakan offset stack
             return IntermediateOperand::create_stack_local(sym_attrs.memory_offset);
         }
    }

    EvaluatedConstant get_compile_time_constant_value(const std::string& id_name) {
        FoundSymbol search_res = search_for_symbol(id_name);
        if (search_res.success && search_res.attributes.is_value_constant && !search_res.attributes.is_array_type()) {
            try {
                 std::string value_string_repr = search_res.attributes.initial_value_representation;
                 // Jika skalar const diinisialisasi menggunakan list (seharusnya tidak terjadi jika parser benar)
                 if (value_string_repr.empty() && !search_res.attributes.constant_array_init_values.empty()){
                     value_string_repr = search_res.attributes.constant_array_init_values[0];
                 }

                 if (!value_string_repr.empty()) {
                    return EvaluatedConstant(true, std::stoi(value_string_repr));
                 } else {
                     trigger_compilation_error("Semantic Error: Constant '" + id_name + "' lacks a defined value.");
                     return EvaluatedConstant(false, 0);
                 }
            } catch (const std::exception& /*e*/) { // std::invalid_argument atau std::out_of_range dari stoi
                trigger_compilation_error("Internal Error: Invalid numeric format for constant '" + id_name + "': " + search_res.attributes.initial_value_representation);
                return EvaluatedConstant(false, 0);
            }
        }
        // Bukan konstanta skalar yang diketahui atau tidak ditemukan
        return EvaluatedConstant(false, 0);
    }


    // -- Generasi IR --
    IntermediateOperand request_temporary_register() {
        // Siklus melalui register $t0-$t(TEMP_REGISTER_POOL_SIZE-1)
        int register_id = m_temp_reg_alloc_counter % TEMP_REGISTER_POOL_SIZE;
        m_temp_reg_alloc_counter++;
        return IntermediateOperand::create_temp_reg(register_id);
    }

    std::string create_new_unique_label(const std::string& prefix = "L_") {
        // Pastikan label yang dihasilkan tidak kosong
        return prefix + std::to_string(m_unique_label_counter++);
    }

    std::string register_string_literal_for_data_segment(const std::string& string_val_with_quotes) {
        if (string_val_with_quotes.length() < 2 || string_val_with_quotes.front() != '"' || string_val_with_quotes.back() != '"') {
             trigger_compilation_error("Invalid string literal format for data segment: " + string_val_with_quotes);
        }
        std::string inner_content = string_val_with_quotes.substr(1, string_val_with_quotes.length() - 2);
        std::string mips_escaped_content;
        bool is_escaping = false;
         for (char c : inner_content) {
             if (is_escaping) {
                 switch (c) {
                     case 'n': mips_escaped_content += "\\n"; break; // MIPS newline
                     case 't': mips_escaped_content += "\\t"; break; // MIPS tab
                     case '\\': mips_escaped_content += "\\\\"; break; // MIPS backslash literal
                     case '"': mips_escaped_content += "\\\""; break; // MIPS quote literal
                     default: mips_escaped_content += '\\'; mips_escaped_content += c; break; // Biarkan escape tak dikenal
                 }
                 is_escaping = false;
             } else if (c == '\\') {
                 is_escaping = true;
             } else {
                 mips_escaped_content += c;
             }
         }
        // Jika escape di akhir string
        if (is_escaping) mips_escaped_content += '\\';


        std::string data_label = "s_data_" + std::to_string(m_string_data_counter++);
        m_data_segment_literals.push_back(std::make_pair(data_label, "\"" + mips_escaped_content + "\""));
        return data_label;
    }

    void add_ir_instruction(IntermediateOpCode op,
                            IntermediateOperand arg1 = IntermediateOperand::create_unspecified(),
                            IntermediateOperand arg2 = IntermediateOperand::create_unspecified(),
                            IntermediateOperand res_tgt = IntermediateOperand::create_unspecified()) {
        m_ir_code_sequence.push_back(IntermediateInstruction(op, std::move(arg1), std::move(arg2), std::move(res_tgt)));
    }

    // Pembantu untuk memuat nilai dari alamat memori ke register temporer baru
    IntermediateOperand generate_load_from_memory_address(IntermediateOperand address_source_operand) {
        IntermediateOperand temp_destination_reg = request_temporary_register();
        if (address_source_operand.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) {
             // Perlu mendapatkan alamat dulu untuk global
             IntermediateOperand address_in_register = request_temporary_register();
             add_ir_instruction(IntermediateOpCode::LOAD_ADDRESS, address_source_operand, IntermediateOperand::create_unspecified(), address_in_register);
             add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, address_in_register, IntermediateOperand::create_unspecified(), temp_destination_reg);
        } else {
            // Alamat lokal atau alamat sudah ada di register
            add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, address_source_operand, IntermediateOperand::create_unspecified(), temp_destination_reg);
        }
        return temp_destination_reg;
    }

    // Pembantu untuk menyimpan nilai (arg1) ke memori (alamat di result_or_target)
    void generate_store_to_memory_address(IntermediateOperand value_source_operand, IntermediateOperand target_address_operand) {
        if (target_address_operand.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) {
            // Perlu mendapatkan alamat dulu untuk global
            IntermediateOperand address_in_register = request_temporary_register();
            add_ir_instruction(IntermediateOpCode::LOAD_ADDRESS, target_address_operand, IntermediateOperand::create_unspecified(), address_in_register);
            // Simpan nilai KE alamat yang ada di address_in_register
            add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, value_source_operand, IntermediateOperand::create_unspecified(), address_in_register);
        } else {
            // Alamat lokal atau alamat sudah ada di register
            add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, value_source_operand, IntermediateOperand::create_unspecified(), target_address_operand);
        }
    }


    // -- Manajemen Spill --
    void reset_function_spill_tracking() {
        m_current_spill_area_offset = 0;
        m_max_spill_area_needed_for_func = 0;
    }

    IntermediateOperand reserve_spill_slot_on_stack() {
        // Slot spill dialokasikan *setelah* variabel lokal dan parameter
        int declared_vars_and_params_size = m_current_local_stack_offset;
        int current_spill_slot_address_offset = declared_vars_and_params_size + m_current_spill_area_offset;
        m_current_spill_area_offset += WORD_SIZE_BYTES;
        m_max_spill_area_needed_for_func = std::max(m_max_spill_area_needed_for_func, m_current_spill_area_offset);
        return IntermediateOperand::create_stack_local(current_spill_slot_address_offset);
    }

    // Spill register temporer jika perlu (mengembalikan operand untuk nilai, bisa jadi alamat memori)
    IntermediateOperand spill_temporary_if_needed(IntermediateOperand temp_reg_op) {
        if (temp_reg_op.type == IntermediateOperand::Type::TEMPORARY_REGISTER) {
             IntermediateOperand spill_destination_address = reserve_spill_slot_on_stack();
             add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, temp_reg_op, IntermediateOperand::create_unspecified(), spill_destination_address);
             return spill_destination_address; // Nilai sekarang ada di memori
        }
        return temp_reg_op; // Bukan register temporer, atau logika pemanggil tidak memerlukan spill
    }

    // Muat ulang nilai dari slot spill ke register temporer
    IntermediateOperand reload_value_from_spill_slot(IntermediateOperand spill_address_op) {
         if (spill_address_op.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) { // Asumsi spill selalu lokal
              IntermediateOperand temp_destination_reg = request_temporary_register();
              add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, spill_address_op, IntermediateOperand::create_unspecified(), temp_destination_reg);
              return temp_destination_reg;
         }
         return spill_address_op; // Bukan alamat spill
    }

    // Pembantu untuk memastikan operand ada di register. Jika immediate, akan dimuat.
    IntermediateOperand ensure_operand_is_in_register(const IntermediateOperand& operand) {
        if (operand.type == IntermediateOperand::Type::IMMEDIATE_VALUE) {
             IntermediateOperand temp_target_register = request_temporary_register();
             add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, operand, IntermediateOperand::create_unspecified(), temp_target_register);
             return temp_target_register;
        }
        // Asumsi tipe lain (TEMPORARY_REGISTER, MIPS_HARDWARE_REGISTER) sudah berupa register.
        // Tangani GLOBAL_VARIABLE_LABEL atau STACK_LOCAL_ADDRESS jika konteks memerlukan nilai, bukan alamat.
        // Versi sederhana ini mengasumsikan jika bukan immediate, itu sudah operand register yang bisa dipakai.
        return operand;
    }


    // --- Metode Parsing Rekursif Turunan (Nama diubah dan struktur sedikit diatur ulang) ---

    // <CompUnit> ::= {<Decl>} {<FuncDef>} <MainFuncDef>
    void parse_top_level_constructs() {
        open_new_scope(false); // Scope global

        // Deklarasi global (variabel dan konstanta)
        while (look_ahead().type == LexTokenType::KEYWORD_CONST ||
               (look_ahead().type == LexTokenType::KEYWORD_INT &&
                look_ahead(1).type == LexTokenType::IDENTIFIER &&
                look_ahead(2).type != LexTokenType::SYM_LPAREN) // Bukan awal definisi fungsi
              )
        {
            parse_global_or_local_declaration();
        }

        // Definisi fungsi (selain main)
        while ((look_ahead().type == LexTokenType::KEYWORD_INT || look_ahead().type == LexTokenType::KEYWORD_VOID) &&
                look_ahead(1).type == LexTokenType::IDENTIFIER &&
                look_ahead(1).lexeme != "main" && // Pastikan bukan 'main'
                look_ahead(2).type == LexTokenType::SYM_LPAREN // Diikuti oleh '('
              )
        {
            parse_function_definition_syntax();
        }

        // Definisi fungsi main
        parse_main_function_definition_syntax();

        // Setelah MainFuncDef, seharusnya tidak ada token lagi selain EOF
        if (look_ahead().type != LexTokenType::END_OF_INPUT) {
            trigger_compilation_error("Parser Error: Unexpected tokens found after 'main' function definition. First unexpected: " + look_ahead().lexeme);
        }
        // Scope global ditutup secara implisit saat objek Compiler dihancurkan
        // atau secara eksplisit jika diperlukan: close_current_scope();
    }

    // <Decl> ::= <ConstDecl> | <VarDecl>
    void parse_global_or_local_declaration() {
        if (look_ahead().type == LexTokenType::KEYWORD_CONST) {
            parse_constant_value_declaration();
        } else if (look_ahead().type == LexTokenType::KEYWORD_INT) {
            parse_variable_item_declaration();
        } else {
             trigger_compilation_error("Parser Error: Expected 'const' or 'int' keyword for a declaration, but found: " + look_ahead().lexeme);
        }
    }

    // <ConstDecl> ::= 'const' 'int' <ConstDef> { ',' <ConstDef> } ';'
    void parse_constant_value_declaration() {
        expect_token_type(LexTokenType::KEYWORD_CONST);
        expect_token_type(LexTokenType::KEYWORD_INT);
        parse_single_constant_definition();
        while (attempt_match_and_consume(LexTokenType::SYM_COMMA)) {
            parse_single_constant_definition();
        }
        expect_token_type(LexTokenType::SYM_SEMICOLON);
    }

    // <ConstDef> ::= Ident { '[' <ConstExp> ']' } '=' <ConstInitVal>
    void parse_single_constant_definition() {
        LexToken identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
        std::vector<int> array_dimension_sizes;
        std::string symbol_data_type = "const int";
        int effective_element_count = 1;

        while (attempt_match_and_consume(LexTokenType::SYM_LBRACKET)) {
            array_dimension_sizes.push_back(evaluate_compile_time_constant_expression());
            expect_token_type(LexTokenType::SYM_RBRACKET);
        }

        if (!array_dimension_sizes.empty()) {
            if (array_dimension_sizes.size() > 1) trigger_compilation_error("Multi-dimensional arrays are not supported in this SysY subset.");
            effective_element_count = array_dimension_sizes[0];
            if (effective_element_count <= 0) trigger_compilation_error("Constant array size must be a positive integer.");
            symbol_data_type += "[]"; // Menandakan tipe array
        }

        expect_token_type(LexTokenType::OP_ASSIGN);

        SymbolAttributes& defined_symbol = add_symbol_to_current_scope(identifier_token.lexeme, symbol_data_type, true, false, effective_element_count);

        std::vector<std::string> parsed_initial_values = parse_constant_value_initializer(effective_element_count);
        defined_symbol.constant_array_init_values = parsed_initial_values; // Simpan nilai-nilai string

        if (effective_element_count == 1 && !parsed_initial_values.empty()) {
            defined_symbol.initial_value_representation = parsed_initial_values[0]; // Untuk skalar, simpan juga representasi tunggal
        } else if (effective_element_count > 1) {
             // Buat representasi string seperti "{v1,v2...}" untuk segmen data inisialisasi global
             std::stringstream representation_builder;
             representation_builder << "{";
             for (size_t i = 0; i < parsed_initial_values.size(); ++i) {
                 representation_builder << parsed_initial_values[i] << (i == parsed_initial_values.size() - 1 ? "" : ",");
             }
             // Isi dengan nol jika list inisialisasi lebih pendek dari ukuran array
             for (int i = parsed_initial_values.size(); i < effective_element_count; ++i) {
                 representation_builder << (i > 0 || !parsed_initial_values.empty() ? "," : "") << "0";
                 // Tambahkan juga ke vektor nilai untuk konsistensi jika diperlukan nanti
                 if (i >= defined_symbol.constant_array_init_values.size()) defined_symbol.constant_array_init_values.push_back("0");
                 else defined_symbol.constant_array_init_values[i] = "0"; // Atau perbarui jika sudah ada slotnya
             }
             representation_builder << "}";
             defined_symbol.initial_value_representation = representation_builder.str();
        }

        // Untuk konstanta lokal, kita perlu menghasilkan kode untuk menyimpan nilai awal di stack
        if (!defined_symbol.is_globally_scoped && effective_element_count > 0) {
            IntermediateOperand base_address_op = get_address_operand_for_symbol(defined_symbol.identifier_name);
            IntermediateOperand actual_base_address_in_reg;

             if (base_address_op.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) {
                 // Hitung alamat absolut dari offset SP ke register
                 actual_base_address_in_reg = request_temporary_register();
                 add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                                    IntermediateOperand::create_mips_reg("$sp"),
                                    IntermediateOperand::create_immediate_from_string(std::to_string(base_address_op.numeric_value_or_offset)),
                                    actual_base_address_in_reg);
             } else {
                 trigger_compilation_error("Internal Error: Unexpected address type for local constant array.");
             }

            for (size_t i = 0; i < defined_symbol.constant_array_init_values.size(); ++i) {
                if (i >= static_cast<size_t>(effective_element_count)) break; // Seharusnya tidak terjadi jika validasi benar

                // 1. Muat nilai konstanta ke register temporer
                IntermediateOperand value_in_reg = request_temporary_register();
                add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE,
                                   IntermediateOperand::create_immediate_from_string(defined_symbol.constant_array_init_values[i]),
                                   IntermediateOperand::create_unspecified(), value_in_reg);

                // 2. Hitung offset elemen (index * 4)
                IntermediateOperand index_in_reg = request_temporary_register();
                add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(i), IntermediateOperand::create_unspecified(), index_in_reg);
                IntermediateOperand offset_in_bytes_reg = request_temporary_register();
                IntermediateOperand word_size_reg = request_temporary_register();
                add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(WORD_SIZE_BYTES), IntermediateOperand::create_unspecified(), word_size_reg);
                add_ir_instruction(IntermediateOpCode::OP_MUL, index_in_reg, word_size_reg, offset_in_bytes_reg);

                // 3. Hitung alamat elemen final (base + offset)
                IntermediateOperand element_final_address_reg = request_temporary_register();
                add_ir_instruction(IntermediateOpCode::OP_ADD, actual_base_address_in_reg, offset_in_bytes_reg, element_final_address_reg);

                // 4. Simpan nilai
                add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, value_in_reg, IntermediateOperand::create_unspecified(), element_final_address_reg);
            }
        }
    }

    // <ConstInitVal> ::= <ConstExp> | '{' [ <ConstInitVal> { ',' <ConstInitVal> } ] '}'
    // Mengembalikan list rata dari hasil ekspresi konstanta (sebagai string)
    std::vector<std::string> parse_constant_value_initializer(int expected_num_elements) {
        std::vector<std::string> collected_values;
        if (attempt_match_and_consume(LexTokenType::SYM_LBRACE)) {
            if (!attempt_match_and_consume(LexTokenType::SYM_RBRACE)) { // Tangani jika bukan kurung kurawal kosong {}
                do {
                    // Panggilan rekursif akan meratakan inisialisasi bersarang jika tata bahasa mendukungnya,
                    // tapi SysY tampaknya menyiratkan inisialisasi rata untuk array 1D.
                    // Asumsikan list rata di sini.
                     std::vector<std::string> single_element_values = parse_constant_value_initializer(1); // Harapkan satu elemen di sini
                     collected_values.insert(collected_values.end(), single_element_values.begin(), single_element_values.end());
                } while (attempt_match_and_consume(LexTokenType::SYM_COMMA));
                expect_token_type(LexTokenType::SYM_RBRACE);
            }
        } else {
            // Inisialisasi skalar atau elemen array tunggal
            collected_values.push_back(std::to_string(evaluate_compile_time_constant_expression()));
        }

        if (expected_num_elements > 1 && collected_values.size() > static_cast<size_t>(expected_num_elements)) {
            trigger_compilation_error("Semantic Error: Too many initializers provided for constant array.");
        }
        // Pengisian dengan nol terjadi di pemanggil (parse_single_constant_definition)
        return collected_values;
    }

    // <ConstExp> ::= <AddExp> // Catatan: Perlu dievaluasi saat kompilasi
    int evaluate_compile_time_constant_expression() {
        // Ini memerlukan jalur evaluasi terpisah yang tidak menghasilkan IR
        // tapi langsung menghitung hasil integer.
        return evaluate_additive_const_expr_recursively();
    }

    // Evaluasi saat kompilasi untuk level AddExp
    int evaluate_additive_const_expr_recursively() {
        int current_value = evaluate_multiplicative_const_expr_recursively();
        while (look_ahead().type == LexTokenType::OP_PLUS || look_ahead().type == LexTokenType::OP_MINUS) {
            LexTokenType operation_token = consume_current_token().type;
            int next_value_component = evaluate_multiplicative_const_expr_recursively();
            if (operation_token == LexTokenType::OP_PLUS) {
                current_value += next_value_component;
            } else { // MINUS
                current_value -= next_value_component;
            }
        }
        return current_value;
    }

    // Evaluasi saat kompilasi untuk level MulExp
    int evaluate_multiplicative_const_expr_recursively() {
        int current_value = evaluate_unary_const_expr_recursively();
        while (look_ahead().type == LexTokenType::OP_MULTIPLY || look_ahead().type == LexTokenType::OP_DIVIDE || look_ahead().type == LexTokenType::OP_MODULO) {
            LexTokenType operation_token = consume_current_token().type;
            int next_value_component = evaluate_unary_const_expr_recursively();
            if (operation_token == LexTokenType::OP_MULTIPLY) {
                current_value *= next_value_component;
            } else { // DIVIDE atau MODULO
                if (next_value_component == 0) {
                    trigger_compilation_error("Semantic Error: Compile-time division or modulo by zero.");
                    return 0; // Hindari crash, kembalikan nilai dummy
                }
                current_value = (operation_token == LexTokenType::OP_DIVIDE) ? (current_value / next_value_component) : (current_value % next_value_component);
            }
        }
        return current_value;
    }

    // Evaluasi saat kompilasi untuk level UnaryExp
    int evaluate_unary_const_expr_recursively() {
        if (attempt_match_and_consume(LexTokenType::OP_PLUS)) {
            return evaluate_unary_const_expr_recursively(); // Unary plus tidak berpengaruh
        } else if (attempt_match_and_consume(LexTokenType::OP_MINUS)) {
            return -evaluate_unary_const_expr_recursively();
        } else if (attempt_match_and_consume(LexTokenType::OP_NOT)) {
            // Not logis untuk konstanta. Asumsi gaya C: !0 adalah 1, !non-zero adalah 0.
            return (evaluate_unary_const_expr_recursively() == 0) ? 1 : 0;
        } else {
             // Ekspresi primer untuk konstanta
             if (look_ahead().type == LexTokenType::SYM_LPAREN) {
                 expect_token_type(LexTokenType::SYM_LPAREN);
                 int val = evaluate_compile_time_constant_expression();
                 expect_token_type(LexTokenType::SYM_RPAREN);
                 return val;
             } else if (look_ahead().type == LexTokenType::INTEGER_LITERAL) {
                 LexToken number_token = expect_token_type(LexTokenType::INTEGER_LITERAL);
                 try { return std::stoi(number_token.lexeme); }
                 catch (const std::exception& /*e*/) { trigger_compilation_error("Internal Error: Invalid integer literal format: " + number_token.lexeme); return 0; }
             } else if (look_ahead().type == LexTokenType::IDENTIFIER) {
                 LexToken identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
                 EvaluatedConstant const_eval_result = get_compile_time_constant_value(identifier_token.lexeme);
                 if (const_eval_result.success) {
                     return const_eval_result.value;
                 } else {
                     trigger_compilation_error("Semantic Error: Identifier '" + identifier_token.lexeme + "' is not a valid compile-time constant in this context.");
                     return 0;
                 }
             } else {
                 trigger_compilation_error("Parser Error: Unexpected token encountered in constant expression: " + look_ahead().lexeme);
                 return 0;
             }
        }
    }

    // <VarDecl> ::= 'int' <VarDef> { ',' <VarDef> } ';'
    void parse_variable_item_declaration() {
         expect_token_type(LexTokenType::KEYWORD_INT);
         parse_single_variable_definition();
         while (attempt_match_and_consume(LexTokenType::SYM_COMMA)) {
             parse_single_variable_definition();
         }
         expect_token_type(LexTokenType::SYM_SEMICOLON);
    }

    // <VarDef> ::= Ident { '[' <ConstExp> ']' } [ '=' <InitVal> ]
    void parse_single_variable_definition() {
        LexToken identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
        std::vector<int> array_dimension_sizes;
        std::string symbol_data_type = "int";
        int effective_element_count = 1;

        while (attempt_match_and_consume(LexTokenType::SYM_LBRACKET)) {
             array_dimension_sizes.push_back(evaluate_compile_time_constant_expression()); // Ukuran array harus konstanta
             expect_token_type(LexTokenType::SYM_RBRACKET);
        }

        if (!array_dimension_sizes.empty()) {
             if (array_dimension_sizes.size() > 1) trigger_compilation_error("Multi-dimensional arrays not supported.");
             effective_element_count = array_dimension_sizes[0];
             if (effective_element_count <= 0) trigger_compilation_error("Variable array size must be a positive integer.");
             symbol_data_type += "[]";
        }

        SymbolAttributes& defined_symbol = add_symbol_to_current_scope(identifier_token.lexeme, symbol_data_type, false, false, effective_element_count);

        if (attempt_match_and_consume(LexTokenType::OP_ASSIGN)) {
            parse_runtime_value_initializer(defined_symbol);
        } else if (defined_symbol.is_globally_scoped) { // Global tanpa inisialisasi eksplisit
             // Array global diinisialisasi nol secara default jika tidak ada inisialisasi
             if (effective_element_count > 1) {
                 std::stringstream repr_builder;
                 repr_builder << "{";
                 for(int i = 0; i < effective_element_count; ++i) repr_builder << "0" << (i == effective_element_count - 1 ? "" : ",");
                 repr_builder << "}";
                 defined_symbol.initial_value_representation = repr_builder.str();
             } else { // Skalar global default ke 0
                 defined_symbol.initial_value_representation = "0";
             }
        }
        // Variabel lokal tanpa inisialisasi tidak diinisialisasi (tidak perlu IR di sini)
    }

    // <InitVal> ::= <Exp> | '{' [ <InitVal> { ',' <InitVal> } ] '}'
    void parse_runtime_value_initializer(SymbolAttributes& target_symbol) {
        bool is_for_aggregate_type = (target_symbol.num_array_elements > 1);

        if (look_ahead().type == LexTokenType::SYM_LBRACE) {
            expect_token_type(LexTokenType::SYM_LBRACE);
            if (!is_for_aggregate_type && target_symbol.num_array_elements == 1) { // Error: skalar diinisialisasi dengan {}
                 trigger_compilation_error("Semantic Error: Brace-initialization used for scalar variable '" + target_symbol.identifier_name + "'.");
            }

            IntermediateOperand base_address_op = get_address_operand_for_symbol(target_symbol.identifier_name);
            IntermediateOperand actual_base_address_in_reg; // Akan menampung alamat dasar aktual

             if (target_symbol.is_globally_scoped) {
                 // Untuk global, alamatnya adalah label, muat ke register
                 actual_base_address_in_reg = request_temporary_register();
                 add_ir_instruction(IntermediateOpCode::LOAD_ADDRESS, base_address_op, IntermediateOperand::create_unspecified(), actual_base_address_in_reg);
             } else { // Lokal
                  if (base_address_op.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) {
                     // Hitung alamat absolut dari offset SP
                     actual_base_address_in_reg = request_temporary_register();
                     add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                                        IntermediateOperand::create_mips_reg("$sp"),
                                        IntermediateOperand::create_immediate_from_string(std::to_string(base_address_op.numeric_value_or_offset)),
                                        actual_base_address_in_reg);
                  } else {
                     trigger_compilation_error("Internal Error: Unexpected address type for local variable array during initialization.");
                  }
             }

            int num_elements_initialized_so_far = 0;
            if (!attempt_match_and_consume(LexTokenType::SYM_RBRACE)) { // Tangani list inisialisasi tidak kosong
                do {
                    if (num_elements_initialized_so_far >= target_symbol.num_array_elements) {
                        trigger_compilation_error("Semantic Error: Too many initializers for array '" + target_symbol.identifier_name + "'.");
                        break; // Hindari error lebih lanjut
                    }
                    // Asumsi list inisialisasi rata untuk array 1D berdasarkan contoh SysY
                    IntermediateOperand element_value_operand = parse_general_expression(); // Parse ekspresi untuk nilai elemen

                    // Hitung alamat elemen: base + index * 4
                    IntermediateOperand index_in_reg = request_temporary_register();
                    add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(num_elements_initialized_so_far), IntermediateOperand::create_unspecified(), index_in_reg);
                    IntermediateOperand offset_in_bytes_reg = request_temporary_register();
                    IntermediateOperand word_size_reg = request_temporary_register();
                    add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(WORD_SIZE_BYTES), IntermediateOperand::create_unspecified(), word_size_reg);
                    add_ir_instruction(IntermediateOpCode::OP_MUL, index_in_reg, word_size_reg, offset_in_bytes_reg);
                    IntermediateOperand element_final_address_reg = request_temporary_register();
                    add_ir_instruction(IntermediateOpCode::OP_ADD, actual_base_address_in_reg, offset_in_bytes_reg, element_final_address_reg);

                    // Simpan nilai
                    add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, element_value_operand, IntermediateOperand::create_unspecified(), element_final_address_reg);

                    num_elements_initialized_so_far++;
                } while (attempt_match_and_consume(LexTokenType::SYM_COMMA));
                expect_token_type(LexTokenType::SYM_RBRACE);
            }
             // Catatan: SysY memerlukan inisialisasi agregat untuk array global.
             // Di sini kita menangani inisialisasi runtime untuk array lokal.
             // Jika array lokal diinisialisasi, elemen sisanya TIDAK otomatis dinolkan oleh kode ini.

             if (target_symbol.is_globally_scoped) {
                  // Jalur ini idealnya tidak tercapai jika inisialisasi global harus ConstExp.
                  trigger_compilation_error("Semantic Error: Runtime initialization syntax (with non-constant expressions in braces) used for global array '" + target_symbol.identifier_name + "'.");
             }

        } else { // Inisialisasi adalah ekspresi tunggal
            if (is_for_aggregate_type) { // Error: array diinisialisasi dengan skalar
                 trigger_compilation_error("Semantic Error: Scalar initialization used for array variable '" + target_symbol.identifier_name + "'.");
            }
            IntermediateOperand value_source_operand = parse_general_expression();

            if (target_symbol.is_globally_scoped) {
                 // Untuk global, ini harus ConstExp, yang sudah ditangani di `declare_symbol`
                 // Jika sampai sini untuk global, berarti ekspresi non-ConstExp digunakan.
                 if (value_source_operand.type != IntermediateOperand::Type::IMMEDIATE_VALUE) {
                     trigger_compilation_error("Semantic Error: Non-constant expression used for global variable initialization '" + target_symbol.identifier_name + "'.");
                 }
                 // Nilai sudah disimpan sebagai string di initial_value_representation
                 // oleh parse_single_variable_definition jika ConstExp.
                 target_symbol.initial_value_representation = value_source_operand.representation;
            } else {
                 // Inisialisasi variabel lokal
                 IntermediateOperand target_mem_address_operand = get_address_operand_for_symbol(target_symbol.identifier_name);
                 generate_store_to_memory_address(value_source_operand, target_mem_address_operand);
            }
        }
    }

    // <FuncDef> ::= <FuncType> Ident '(' [ <FuncFParams> ] ')' <Block>
    void parse_function_definition_syntax() {
         std::string declared_return_type = parse_function_return_type_specifier();
         LexToken function_identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
         std::string function_name_str = function_identifier_token.lexeme;

         // Deklarasikan fungsi di scope global (m_symbol_table_manager[0])
         if (m_symbol_table_manager.empty()) trigger_compilation_error("Internal Error: Global scope is missing during function declaration.");
         // Cek potensi redefinisi di scope global
         if (m_symbol_table_manager[0].count(function_name_str)) {
              // trigger_compilation_error("Semantic Error: Redefinition of function '" + function_name_str + "'.");
         }
         // Simpan info fungsi di peta scope *global*
         m_symbol_table_manager[0][function_name_str] = SymbolAttributes(function_name_str, declared_return_type, 0, false, true, true);

         // Persiapan untuk parsing body fungsi
         std::string mips_function_label = "FUNC_" + function_name_str;
         m_current_function_return_label = create_new_unique_label("L_epilogue_FUNC_" + function_name_str + "_");

         expect_token_type(LexTokenType::SYM_LPAREN);
         open_new_scope(true); // Masuk ke scope lokal fungsi

         std::vector<std::string> declared_parameter_names; // Lacak nama parameter untuk generasi prologue
         if (look_ahead().type != LexTokenType::SYM_RPAREN) { // Jika ada parameter
             declared_parameter_names = parse_function_formal_parameter_list();
         }
         expect_token_type(LexTokenType::SYM_RPAREN);

         // --- Generasi Prologue Fungsi (Awal) ---
         add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_code_label(mips_function_label));

         // Simpan titik sisipan untuk prologue lengkap (penyesuaian stack, simpan $ra, pemuatan param)
         size_t prologue_ir_insertion_point = m_ir_code_sequence.size();
         add_ir_instruction(IntermediateOpCode::NO_OPERATION); // Placeholder

         // --- Parse Body Fungsi ---
         parse_code_block(false); // Parse statement blok yang merupakan body fungsi

         // --- Hitung Ukuran Frame dan Hasilkan Prologue Lengkap ---
         int space_for_vars_and_params = m_current_local_stack_offset; // Ruang total untuk param + var lokal
         int space_for_spills = m_max_spill_area_needed_for_func;       // Ruang total untuk spill
         int total_frame_content_size = space_for_vars_and_params + space_for_spills;
         // Ukuran frame = ruang untuk lokal/param/spill + ruang untuk $ra + padding alignment
         int final_frame_size_bytes = (total_frame_content_size + WORD_SIZE_BYTES + (2*WORD_SIZE_BYTES -1)) & ~(2*WORD_SIZE_BYTES -1); // Align ke 8 byte (ukuran 2 word)

         std::vector<IntermediateInstruction> actual_prologue_irs;
         // 1. Sesuaikan stack pointer
         actual_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                                    IntermediateOperand::create_mips_reg("$sp"),
                                    IntermediateOperand::create_immediate_from_string("-" + std::to_string(final_frame_size_bytes)),
                                    IntermediateOperand::create_mips_reg("$sp")));
         // 2. Simpan return address ($ra)
         int return_address_save_offset = final_frame_size_bytes - WORD_SIZE_BYTES;
         actual_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_SW, // op1=src_reg, op2=addr
                                    IntermediateOperand::create_mips_reg("$ra"),
                                    IntermediateOperand::create_stack_local(return_address_save_offset)));

          // 3. Simpan parameter dari register/stack pemanggil ke frame stack lokal
         for (size_t i = 0; i < declared_parameter_names.size(); ++i) {
             FoundSymbol param_symbol_data = search_for_symbol(declared_parameter_names[i]); // Seharusnya ada di scope saat ini
             if (!param_symbol_data.success) { trigger_compilation_error("Internal Error: Parameter symbol '" + declared_parameter_names[i] + "' not found post-declaration."); continue; }

             IntermediateOperand param_storage_on_local_stack = IntermediateOperand::create_stack_local(param_symbol_data.attributes.memory_offset);

             if (i < 4) { // 4 parameter pertama ada di $a0-$a3
                 actual_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_SW, // op1=src_reg, op2=addr
                                            IntermediateOperand::create_mips_reg("$a" + std::to_string(i)),
                                            param_storage_on_local_stack));
             } else { // Parameter berikutnya ada di stack pemanggil
                 // Offset relatif terhadap SP *baru* setelah alokasi frame: final_frame_size_bytes + (indeks_arg - 4) * 4
                 int arg_location_on_caller_stack_offset = final_frame_size_bytes + (i - 4) * WORD_SIZE_BYTES;
                 IntermediateOperand caller_stack_argument_address = IntermediateOperand::create_stack_local(arg_location_on_caller_stack_offset);
                 IntermediateOperand temp_load_register = IntermediateOperand::create_mips_reg(MIPS_HELPER_REG_1); // Gunakan register scratch

                 // Muat dari stack pemanggil ke register temporer
                 actual_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_LW, // op1=dest_reg, op2=addr
                                            temp_load_register,
                                            caller_stack_argument_address));
                 // Simpan dari register temporer ke frame lokal
                 actual_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_SW, // op1=src_reg, op2=addr
                                            temp_load_register,
                                            param_storage_on_local_stack));
             }
         }

         // Ganti placeholder NOP dengan prologue aktual
         if (prologue_ir_insertion_point < m_ir_code_sequence.size() && m_ir_code_sequence[prologue_ir_insertion_point].operation == IntermediateOpCode::NO_OPERATION) {
              m_ir_code_sequence.erase(m_ir_code_sequence.begin() + prologue_ir_insertion_point);
              m_ir_code_sequence.insert(m_ir_code_sequence.begin() + prologue_ir_insertion_point, actual_prologue_irs.begin(), actual_prologue_irs.end());
         } else {
              trigger_compilation_error("Internal Error: Prologue IR insertion point mismatch for function '" + function_name_str + "'.");
         }


         // --- Generasi Epilogue Fungsi ---
         // Pastikan ada jalur ke epilogue (jump implisit jika perlu)
          bool ends_with_flow_control = false;
          if (!m_ir_code_sequence.empty()) {
              IntermediateOpCode last_op = m_ir_code_sequence.back().operation;
              ends_with_flow_control = (last_op == IntermediateOpCode::JUMP_UNCONDITIONAL ||
                                        last_op == IntermediateOpCode::RETURN_VALUE ||
                                        last_op == IntermediateOpCode::RETURN_VOID ||
                                        last_op == IntermediateOpCode::JUMP_TO_REGISTER);
          }

          // Jika instruksi terakhir bukan return atau jump, tambahkan jump ke epilogue
          if (!ends_with_flow_control && !m_current_function_return_label.empty()) {
                add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_current_function_return_label));
          }

         // Label Epilogue
         if (m_current_function_return_label.empty()) trigger_compilation_error("Internal error: function epilogue label is empty for " + function_name_str);
         add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_current_function_return_label));
         // 1. Kembalikan return address
         add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_LW, // op1=dest_reg, op2=addr
                            IntermediateOperand::create_mips_reg("$ra"),
                            IntermediateOperand::create_stack_local(return_address_save_offset));
         // 2. Dealokasi frame stack
         add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                            IntermediateOperand::create_mips_reg("$sp"),
                            IntermediateOperand::create_immediate_from_string(std::to_string(final_frame_size_bytes)),
                            IntermediateOperand::create_mips_reg("$sp"));
         // 3. Kembali ke pemanggil
         add_ir_instruction(IntermediateOpCode::JUMP_TO_REGISTER, IntermediateOperand::create_mips_reg("$ra"));

         close_current_scope();
         m_current_function_return_label = ""; // Bersihkan konteks
    }

    // <FuncType> ::= 'void' | 'int'
    std::string parse_function_return_type_specifier() {
        if (look_ahead().type == LexTokenType::KEYWORD_VOID) {
            return consume_current_token().lexeme;
        } else if (look_ahead().type == LexTokenType::KEYWORD_INT) {
            return consume_current_token().lexeme;
        } else {
            trigger_compilation_error("Parser Error: Expected 'void' or 'int' for function return type specifier.");
            return ""; // Tidak akan tercapai
        }
    }

    // <FuncFParams> ::= <FuncFParam> { ',' <FuncFParam> }
    // Mengembalikan list nama parameter yang dideklarasikan
    std::vector<std::string> parse_function_formal_parameter_list() {
        std::vector<std::string> parameter_names_list;
        parameter_names_list.push_back(parse_single_function_formal_parameter());
        while (attempt_match_and_consume(LexTokenType::SYM_COMMA)) {
            parameter_names_list.push_back(parse_single_function_formal_parameter());
        }
        return parameter_names_list;
    }

    // <FuncFParam> ::= 'int' Ident ['[' ']'] { '[' <ConstExp> ']' }
    // Disederhanakan: hanya parameter int, opsional array 1D
    std::string parse_single_function_formal_parameter() {
        expect_token_type(LexTokenType::KEYWORD_INT);
        LexToken identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
        std::string param_id_name = identifier_token.lexeme;
        std::string param_data_type = "int";
        // Untuk parameter array, kita hanya menyimpan alamatnya di stack, jadi ukurannya 1 word.
        int effective_stack_allocation_size = 1;

        // Cek sintaks parameter array
        if (attempt_match_and_consume(LexTokenType::SYM_LBRACKET)) {
            expect_token_type(LexTokenType::SYM_RBRACKET); // Kurung pertama harus kosong: int a[]
            param_data_type = "int[]"; // Tandai sebagai array (pointer secara konseptual)

            // Ukuran dimensi opsional (diabaikan dalam subset SysY untuk parameter fungsi, tapi parse)
            while (attempt_match_and_consume(LexTokenType::SYM_LBRACKET)) {
                evaluate_compile_time_constant_expression(); // Evaluasi tapi abaikan ukurannya
                expect_token_type(LexTokenType::SYM_RBRACKET);
            }
        }
        // Deklarasikan simbol parameter di scope saat ini.
        add_symbol_to_current_scope(param_id_name, param_data_type, false, false, effective_stack_allocation_size);
        return param_id_name;
    }

    // <MainFuncDef> ::= 'int' 'main' '(' ')' <Block>
    void parse_main_function_definition_syntax() {
        expect_token_type(LexTokenType::KEYWORD_INT);
        expect_token_type(LexTokenType::KEYWORD_MAIN);

        // Deklarasikan main di scope global
        if (m_symbol_table_manager.empty()) trigger_compilation_error("Internal Error: Global scope missing for 'main' declaration.");
        // Cek jika 'main' sudah dideklarasikan (misal sebagai variabel global)
        if (m_symbol_table_manager[0].count("main")) {
             // trigger_compilation_error("Semantic Error: Identifier 'main' redefined.");
        }
         m_symbol_table_manager[0]["main"] = SymbolAttributes("main", "int", 0, false, true, true);

        std::string mips_main_label = "FUNC_main";
        m_current_function_return_label = create_new_unique_label("L_epilogue_FUNC_main_");

        expect_token_type(LexTokenType::SYM_LPAREN);
        expect_token_type(LexTokenType::SYM_RPAREN);
        open_new_scope(true); // Masuk ke scope lokal main

        // --- Prologue Main ---
        add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_code_label(mips_main_label));
        size_t main_prologue_ir_insertion_point = m_ir_code_sequence.size();
        add_ir_instruction(IntermediateOpCode::NO_OPERATION); // Placeholder untuk setup frame stack

        // --- Parse Body ---
        parse_code_block(false); // Parse body main

        // --- Hitung Ukuran Frame dan Hasilkan Prologue Main ---
         int space_for_local_vars = m_current_local_stack_offset; // Ruang total untuk lokal (main tidak punya param)
         int space_for_spills = m_max_spill_area_needed_for_func;
         int total_main_frame_content_size = space_for_local_vars + space_for_spills;
         int final_main_frame_size_bytes = (total_main_frame_content_size + WORD_SIZE_BYTES + (2*WORD_SIZE_BYTES-1)) & ~(2*WORD_SIZE_BYTES-1); // +4 untuk $ra, align ke 8

         std::vector<IntermediateInstruction> main_prologue_irs;
         main_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                                    IntermediateOperand::create_mips_reg("$sp"),
                                    IntermediateOperand::create_immediate_from_string("-" + std::to_string(final_main_frame_size_bytes)),
                                    IntermediateOperand::create_mips_reg("$sp")));
         int main_ra_save_offset = final_main_frame_size_bytes - WORD_SIZE_BYTES;
         main_prologue_irs.push_back(IntermediateInstruction(IntermediateOpCode::MIPS_DIRECT_SW, // op1=src_reg, op2=addr
                                    IntermediateOperand::create_mips_reg("$ra"),
                                    IntermediateOperand::create_stack_local(main_ra_save_offset)));

          if (main_prologue_ir_insertion_point < m_ir_code_sequence.size() && m_ir_code_sequence[main_prologue_ir_insertion_point].operation == IntermediateOpCode::NO_OPERATION) {
              m_ir_code_sequence.erase(m_ir_code_sequence.begin() + main_prologue_ir_insertion_point);
              m_ir_code_sequence.insert(m_ir_code_sequence.begin() + main_prologue_ir_insertion_point, main_prologue_irs.begin(), main_prologue_irs.end());
         } else {
              trigger_compilation_error("Internal Error: Prologue IR insertion point mismatch for 'main' function.");
         }

        // --- Epilogue Main ---
         // Pastikan ada jalur ke epilogue (return 0 implisit jika perlu)
          bool main_ends_with_flow_control = false;
          if (!m_ir_code_sequence.empty()) {
              IntermediateOpCode last_op_in_main = m_ir_code_sequence.back().operation;
              main_ends_with_flow_control = (last_op_in_main == IntermediateOpCode::JUMP_UNCONDITIONAL ||
                                             last_op_in_main == IntermediateOpCode::RETURN_VALUE ||
                                             last_op_in_main == IntermediateOpCode::RETURN_VOID ||
                                             last_op_in_main == IntermediateOpCode::JUMP_TO_REGISTER);
          }

          if (!main_ends_with_flow_control && !m_current_function_return_label.empty()) {
              // Main secara implisit mengembalikan 0 jika eksekusi mencapai akhir
              add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(0), IntermediateOperand::create_unspecified(), IntermediateOperand::create_mips_reg("$v0"));
              add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_current_function_return_label));
          }

        if (m_current_function_return_label.empty()) trigger_compilation_error("Internal error: main epilogue label is empty");
        add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_current_function_return_label));
        add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_LW, // op1=dest_reg, op2=addr
                           IntermediateOperand::create_mips_reg("$ra"),
                           IntermediateOperand::create_stack_local(main_ra_save_offset)); // Kembalikan $ra
        add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                           IntermediateOperand::create_mips_reg("$sp"),
                           IntermediateOperand::create_immediate_from_string(std::to_string(final_main_frame_size_bytes)),
                           IntermediateOperand::create_mips_reg("$sp")); // Dealokasi frame
        add_ir_instruction(IntermediateOpCode::JUMP_TO_REGISTER, IntermediateOperand::create_mips_reg("$ra")); // Kembali

        close_current_scope();
        m_current_function_return_label = ""; // Bersihkan konteks
    }

    // <Block> ::= '{' { <BlockItem> } '}'
    void parse_code_block(bool create_new_lexical_scope = true) {
        expect_token_type(LexTokenType::SYM_LBRACE);
        if (create_new_lexical_scope) {
            open_new_scope(false); // Masuk ke scope blok (bukan scope fungsi)
        }

        while (look_ahead().type != LexTokenType::SYM_RBRACE && look_ahead().type != LexTokenType::END_OF_INPUT) {
            parse_block_level_item();
        }

        expect_token_type(LexTokenType::SYM_RBRACE);
        if (create_new_lexical_scope) {
            close_current_scope();
        }
    }

    // <BlockItem> ::= <Decl> | <Stmt>
    void parse_block_level_item() {
        if (look_ahead().type == LexTokenType::KEYWORD_CONST || look_ahead().type == LexTokenType::KEYWORD_INT) {
            parse_global_or_local_declaration(); // Bisa deklarasi di dalam blok
        } else {
            parse_executable_statement();
        }
    }

    // <Stmt> ::= ...
    void parse_executable_statement() {
        LexTokenType next_token_indicator = look_ahead().type;

        if (next_token_indicator == LexTokenType::SYM_LBRACE) {
            parse_code_block(true); // Statement blok membuat scope baru
        }
        else if (next_token_indicator == LexTokenType::KEYWORD_IF) {
            parse_conditional_if_statement();
        }
        else if (next_token_indicator == LexTokenType::KEYWORD_WHILE) {
            parse_iterative_while_statement();
        }
        else if (next_token_indicator == LexTokenType::KEYWORD_BREAK) {
            expect_token_type(LexTokenType::KEYWORD_BREAK);
             if (m_loop_break_label_stack.empty()) {
                 trigger_compilation_error("Semantic Error: 'break' statement found outside of a loop construct.");
             } else {
                 add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_loop_break_label_stack.back()));
             }
            expect_token_type(LexTokenType::SYM_SEMICOLON);
        }
        else if (next_token_indicator == LexTokenType::KEYWORD_CONTINUE) {
             expect_token_type(LexTokenType::KEYWORD_CONTINUE);
             if (m_loop_continue_label_stack.empty()) {
                 trigger_compilation_error("Semantic Error: 'continue' statement found outside of a loop construct.");
             } else {
                 add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_loop_continue_label_stack.back()));
             }
             expect_token_type(LexTokenType::SYM_SEMICOLON);
        }
        else if (next_token_indicator == LexTokenType::KEYWORD_RETURN) {
             expect_token_type(LexTokenType::KEYWORD_RETURN);
             IntermediateOperand return_value_op;
             bool has_explicit_return_value = false;
             if (look_ahead().type != LexTokenType::SYM_SEMICOLON) { // Jika ada ekspresi return
                 return_value_op = parse_general_expression();
                 has_explicit_return_value = true;
             }
             expect_token_type(LexTokenType::SYM_SEMICOLON);

             if (has_explicit_return_value) {
                 add_ir_instruction(IntermediateOpCode::RETURN_VALUE, return_value_op);
             } else {
                 add_ir_instruction(IntermediateOpCode::RETURN_VOID);
             }
              // Tambahkan jump tak bersyarat ke epilogue fungsi setelah IR return
              if (!m_current_function_return_label.empty()) {
                   add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(m_current_function_return_label));
              } else {
                   // Ini seharusnya tidak terjadi jika return ada di dalam fungsi yang valid
                   trigger_compilation_error("Internal Error: Return statement encountered outside of a valid function context (epilogue label missing).");
              }
        }
        else if (next_token_indicator == LexTokenType::KEYWORD_PRINTF) {
            parse_formatted_print_statement();
        }
        else if (next_token_indicator == LexTokenType::SYM_SEMICOLON) { // Statement kosong
            consume_current_token();
        }
        else {
            // Bisa jadi statement assignment (<LVal> = ...) atau statement ekspresi (<Exp>;)
            // Perlu lookahead lebih jauh atau parse LVal secara spekulatif.
            // Struktur asli memeriksa lookahead untuk ASSIGN/LBRACK. Kita lakukan serupa.

            bool looks_like_assignment = false;
            if (next_token_indicator == LexTokenType::IDENTIFIER) {
                // Cek apakah diikuti oleh assignment atau akses array yang mengarah ke assignment
                size_t k = 1; // Indeks lookahead
                while(look_ahead(k).type == LexTokenType::SYM_LBRACKET) {
                    // Lewati ekspresi dalam kurung siku - lookahead sederhana
                    size_t bracket_depth = 1;
                    k++; // Lewati '['
                    while(bracket_depth > 0 && look_ahead(k).type != LexTokenType::END_OF_INPUT){
                         if(look_ahead(k).type == LexTokenType::SYM_LBRACKET) bracket_depth++;
                         else if(look_ahead(k).type == LexTokenType::SYM_RBRACKET) bracket_depth--;
                         k++;
                         if(bracket_depth == 0) break; // Temukan ']' yang cocok
                    }
                    if (bracket_depth > 0) break; // Kurung siku salah format atau EOF
                }
                 if (look_ahead(k).type == LexTokenType::OP_ASSIGN) {
                     looks_like_assignment = true;
                 }
            }


            if (looks_like_assignment) {
                // Statement Assignment: <LVal> = <Exp> | <LVal> = getint()
                bool is_lval_array_base_address;
                IntermediateOperand lvalue_target_address_operand = parse_lvalue_expression(&is_lval_array_base_address);
                 if (is_lval_array_base_address) { // Tidak bisa assign ke alamat dasar array
                      trigger_compilation_error("Semantic Error: Cannot assign directly to an array's base address.");
                 }

                 // Tangani potensi kebutuhan untuk spill alamat LVal jika ada di register temporer
                 // sebelum parsing ekspresi RHS yang mungkin menimpa register itu.
                 bool was_lval_address_spilled = false;
                 IntermediateOperand original_lval_addr_op_before_spill = lvalue_target_address_operand;
                 // int spill_state_backup_for_statement = m_current_spill_area_offset;

                 if (lvalue_target_address_operand.type == IntermediateOperand::Type::TEMPORARY_REGISTER) {
                      lvalue_target_address_operand = reserve_spill_slot_on_stack(); // Dapatkan lokasi spill
                      add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, original_lval_addr_op_before_spill, IntermediateOperand::create_unspecified(), lvalue_target_address_operand);
                      was_lval_address_spilled = true;
                 }

                expect_token_type(LexTokenType::OP_ASSIGN);

                IntermediateOperand right_hand_side_value_operand;
                if (look_ahead().type == LexTokenType::KEYWORD_GETINT) {
                    expect_token_type(LexTokenType::KEYWORD_GETINT);
                    expect_token_type(LexTokenType::SYM_LPAREN);
                    expect_token_type(LexTokenType::SYM_RPAREN);
                    right_hand_side_value_operand = request_temporary_register();
                    add_ir_instruction(IntermediateOpCode::SYSTEM_GETINT, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), right_hand_side_value_operand);
                } else {
                    right_hand_side_value_operand = parse_general_expression();
                }
                expect_token_type(LexTokenType::SYM_SEMICOLON);

                // Muat ulang alamat LVal dari slot spill jika di-spill
                IntermediateOperand final_lvalue_store_target_address = lvalue_target_address_operand;
                if (was_lval_address_spilled) {
                    final_lvalue_store_target_address = request_temporary_register(); // Muat ke temporer baru
                     add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, lvalue_target_address_operand, IntermediateOperand::create_unspecified(), final_lvalue_store_target_address);
                     // m_current_spill_area_offset = spill_state_backup_for_statement; // Hati-hati. Pelacakan maks cukup.
                }

                // Hasilkan operasi store
                 generate_store_to_memory_address(right_hand_side_value_operand, final_lvalue_store_target_address);

            } else {
                // Statement Ekspresi: [<Exp>] ;
                if (look_ahead().type != LexTokenType::SYM_SEMICOLON) { // Jika bukan statement kosong ;
                     parse_general_expression(); // Evaluasi ekspresi untuk efek samping, buang hasil operand
                }
                expect_token_type(LexTokenType::SYM_SEMICOLON);
            }
        }
    }

    void parse_conditional_if_statement() {
        expect_token_type(LexTokenType::KEYWORD_IF);
        expect_token_type(LexTokenType::SYM_LPAREN);
        IntermediateOperand condition_result_operand = parse_boolean_condition_expression();
        expect_token_type(LexTokenType::SYM_RPAREN);

        std::string label_for_else_path = create_new_unique_label("if_else_");
        std::string label_after_if_construct = create_new_unique_label("if_end_");

        // Jika kondisi false (0), branch ke label_for_else_path
        add_ir_instruction(IntermediateOpCode::BRANCH_IF_ZERO, condition_result_operand, IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_for_else_path));

        // Blok Then
        parse_executable_statement();

        if (attempt_match_and_consume(LexTokenType::KEYWORD_ELSE)) {
            // Jika blok 'then' selesai, lompat tanpa syarat ke label_after_if_construct
            add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_after_if_construct));
            // Label untuk awal blok else
            add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_for_else_path));
            // Blok Else
            parse_executable_statement();
            // Label untuk akhir seluruh struktur if-else
            add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_after_if_construct));
        } else {
            // Tidak ada blok else, label_for_else_path menandai akhir if
            add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_for_else_path));
        }
    }

    void parse_iterative_while_statement() {
        expect_token_type(LexTokenType::KEYWORD_WHILE);

        std::string loop_condition_check_label = create_new_unique_label("while_cond_");
        std::string loop_exit_label = create_new_unique_label("while_end_");

        // Dorong label ke tumpukan untuk konteks break/continue
        m_loop_continue_label_stack.push_back(loop_condition_check_label);
        m_loop_break_label_stack.push_back(loop_exit_label);

        // --- Pemeriksaan Kondisi Loop ---
        add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(loop_condition_check_label));
        expect_token_type(LexTokenType::SYM_LPAREN);
        IntermediateOperand condition_result_operand = parse_boolean_condition_expression();
        expect_token_type(LexTokenType::SYM_RPAREN);

        // Jika kondisi false (0), branch ke loop_exit_label
        add_ir_instruction(IntermediateOpCode::BRANCH_IF_ZERO, condition_result_operand, IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(loop_exit_label));

        // --- Body Loop ---
        parse_executable_statement(); // Statement yang diatur oleh while

        // --- Lompat kembali ke Pemeriksaan Kondisi ---
        add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(loop_condition_check_label));

        // --- Akhir Loop ---
        add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(loop_exit_label));

        // Pop label dari tumpukan konteks
        m_loop_continue_label_stack.pop_back();
        m_loop_break_label_stack.pop_back();
    }

    void parse_formatted_print_statement() {
        expect_token_type(LexTokenType::KEYWORD_PRINTF);
        expect_token_type(LexTokenType::SYM_LPAREN);
        LexToken format_string_lex_token = expect_token_type(LexTokenType::STRING_LITERAL);
        std::string raw_format_string_lexeme = format_string_lex_token.lexeme;

        // Parsing argumen: evaluasi dan spill ke stack segera
        std::vector<IntermediateOperand> argument_value_spill_locations;
        // int spill_area_state_before_printf_args = m_current_spill_area_offset;

        while (attempt_match_and_consume(LexTokenType::SYM_COMMA)) {
             IntermediateOperand argument_evaluated_value = parse_general_expression();
             // Spill nilai argumen ke slot spill khusus untuk printf
             IntermediateOperand spill_destination_addr = reserve_spill_slot_on_stack();
             add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, argument_evaluated_value, IntermediateOperand::create_unspecified(), spill_destination_addr);
             argument_value_spill_locations.push_back(spill_destination_addr); // Simpan alamat tempat arg di-spill
        }
        expect_token_type(LexTokenType::SYM_RPAREN);
        expect_token_type(LexTokenType::SYM_SEMICOLON);

        // --- Hasilkan IR untuk eksekusi printf ---
        // Proses string format dan hasilkan panggilan print, muat ulang argumen dari spill jika perlu

        std::string format_string_content_only = raw_format_string_lexeme.substr(1, raw_format_string_lexeme.length() - 2); // Hapus kutip
        size_t current_printf_arg_index = 0;
        std::string current_text_segment_being_built;
        bool inside_escape_char = false;

        for (size_t i = 0; i < format_string_content_only.length(); ++i) {
            char current_char_in_fmt = format_string_content_only[i];

            if (inside_escape_char) {
                 // Di SysY, format string printf sederhana, \n adalah yang utama
                 // Karakter escape literal seperti \\, \" akan ditangani saat membuat string literal untuk .data
                 current_text_segment_being_built += current_char_in_fmt;
                 inside_escape_char = false;
            } else if (current_char_in_fmt == '\\') {
                 current_text_segment_being_built += current_char_in_fmt;
                 inside_escape_char = true; // Karakter berikutnya adalah bagian dari escape
            } else if (current_char_in_fmt == '%' && i + 1 < format_string_content_only.length() && format_string_content_only[i + 1] == 'd') {
                // Temukan %d, print segmen teks sebelumnya jika ada
                if (!current_text_segment_being_built.empty()) {
                     // Perlu menyertakan kutip untuk register_string_literal_for_data_segment
                     std::string string_label_for_data = register_string_literal_for_data_segment("\"" + current_text_segment_being_built + "\"");
                     add_ir_instruction(IntermediateOpCode::SYSTEM_PRINT_STRING, IntermediateOperand::create_string_label(string_label_for_data));
                     current_text_segment_being_built.clear();
                }

                // Print argumen yang sesuai
                if (current_printf_arg_index >= argument_value_spill_locations.size()) {
                     trigger_compilation_error("Semantic Error: Not enough arguments provided for printf format string.");
                     break; // Hindari error lebih lanjut
                }
                // Muat ulang argumen dari slot spill-nya ke register temporer
                IntermediateOperand argument_spill_address = argument_value_spill_locations[current_printf_arg_index];
                IntermediateOperand argument_value_in_temp_reg = request_temporary_register();
                add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, argument_spill_address, IntermediateOperand::create_unspecified(), argument_value_in_temp_reg);
                add_ir_instruction(IntermediateOpCode::SYSTEM_PRINT_INT, argument_value_in_temp_reg);

                current_printf_arg_index++;
                i++; // Lewati 'd'
            } else {
                current_text_segment_being_built += current_char_in_fmt;
            }
        }

        // Print segmen teks sisa setelah %d terakhir atau jika tidak ada
        if (!current_text_segment_being_built.empty()) {
             std::string string_label_for_data = register_string_literal_for_data_segment("\"" + current_text_segment_being_built + "\"");
             add_ir_instruction(IntermediateOpCode::SYSTEM_PRINT_STRING, IntermediateOperand::create_string_label(string_label_for_data));
        }

        if (current_printf_arg_index < argument_value_spill_locations.size()) {
             trigger_compilation_error("Semantic Error: Too many arguments provided for printf format string.");
        }
        // m_current_spill_area_offset = spill_area_state_before_printf_args; // Hati-hati. Pelacakan maks cukup.
    }

    // <Exp> ::= <AddExp>
    // Mengembalikan operand yang berisi hasil (register atau immediate)
    IntermediateOperand parse_general_expression() {
        return parse_additive_level_expression();
    }

    // <AddExp> ::= <MulExp> { ('+' | '-') <MulExp> }
    IntermediateOperand parse_additive_level_expression() {
        IntermediateOperand left_hand_operand = parse_multiplicative_level_expression();

        while (look_ahead().type == LexTokenType::OP_PLUS || look_ahead().type == LexTokenType::OP_MINUS) {
            LexTokenType operation_token_type = consume_current_token().type;
            IntermediateOpCode ir_operation = (operation_token_type == LexTokenType::OP_PLUS) ? IntermediateOpCode::OP_ADD : IntermediateOpCode::OP_SUB;

             // Spill operand kiri jika itu register temporer sebelum parsing sisi kanan
             bool was_left_operand_spilled = false;
             IntermediateOperand original_left_op_before_spill = left_hand_operand;
             // int spill_state_backup_for_add = m_current_spill_area_offset;
             if (left_hand_operand.type == IntermediateOperand::Type::TEMPORARY_REGISTER) {
                 left_hand_operand = reserve_spill_slot_on_stack();
                 add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, original_left_op_before_spill, IntermediateOperand::create_unspecified(), left_hand_operand);
                 was_left_operand_spilled = true;
             }

            IntermediateOperand right_hand_operand = parse_multiplicative_level_expression();

            // Muat ulang operand kiri jika di-spill
             IntermediateOperand final_left_operand_for_op = left_hand_operand;
             if (was_left_operand_spilled) {
                  final_left_operand_for_op = request_temporary_register();
                  add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, left_hand_operand, IntermediateOperand::create_unspecified(), final_left_operand_for_op);
                  // m_current_spill_area_offset = spill_state_backup_for_add; // Pelacakan maks lebih aman.
             }

            // Pastikan kedua operand ada di register
             final_left_operand_for_op = ensure_operand_is_in_register(final_left_operand_for_op);
             right_hand_operand = ensure_operand_is_in_register(right_hand_operand);

            IntermediateOperand operation_result_operand = request_temporary_register();
            add_ir_instruction(ir_operation, final_left_operand_for_op, right_hand_operand, operation_result_operand);
            left_hand_operand = operation_result_operand; // Hasil menjadi operand kiri untuk iterasi berikutnya
        }
        return left_hand_operand;
    }

    // <MulExp> ::= <UnaryExp> { ('*' | '/' | '%') <UnaryExp> }
    IntermediateOperand parse_multiplicative_level_expression() {
         IntermediateOperand left_hand_operand = parse_unary_level_expression();

         while (look_ahead().type == LexTokenType::OP_MULTIPLY || look_ahead().type == LexTokenType::OP_DIVIDE || look_ahead().type == LexTokenType::OP_MODULO) {
             LexTokenType operation_token_type = consume_current_token().type;
             IntermediateOpCode ir_operation;
             if (operation_token_type == LexTokenType::OP_MULTIPLY) ir_operation = IntermediateOpCode::OP_MUL;
             else if (operation_token_type == LexTokenType::OP_DIVIDE) ir_operation = IntermediateOpCode::OP_DIV;
             else ir_operation = IntermediateOpCode::OP_MOD; // MODULO

              bool was_left_operand_spilled = false;
              IntermediateOperand original_left_op_before_spill = left_hand_operand;
              // int spill_state_backup_for_mul = m_current_spill_area_offset;
              if (left_hand_operand.type == IntermediateOperand::Type::TEMPORARY_REGISTER) {
                  left_hand_operand = reserve_spill_slot_on_stack();
                  add_ir_instruction(IntermediateOpCode::STORE_TO_MEMORY, original_left_op_before_spill, IntermediateOperand::create_unspecified(), left_hand_operand);
                  was_left_operand_spilled = true;
              }

             IntermediateOperand right_hand_operand = parse_unary_level_expression();

              IntermediateOperand final_left_operand_for_op = left_hand_operand;
              if (was_left_operand_spilled) {
                   final_left_operand_for_op = request_temporary_register();
                   add_ir_instruction(IntermediateOpCode::LOAD_FROM_MEMORY, left_hand_operand, IntermediateOperand::create_unspecified(), final_left_operand_for_op);
                    // m_current_spill_area_offset = spill_state_backup_for_mul; // Pelacakan maks lebih aman.
              }

              final_left_operand_for_op = ensure_operand_is_in_register(final_left_operand_for_op);
              right_hand_operand = ensure_operand_is_in_register(right_hand_operand);

             IntermediateOperand operation_result_operand = request_temporary_register();
             add_ir_instruction(ir_operation, final_left_operand_for_op, right_hand_operand, operation_result_operand);
             left_hand_operand = operation_result_operand;
         }
         return left_hand_operand;
    }

    // <UnaryExp> ::= <PrimaryExp> | Ident '(' [FuncRParams] ')' | ('+' | '-' | '!') <UnaryExp>
    IntermediateOperand parse_unary_level_expression() {
        LexTokenType next_op_type = look_ahead().type;

        if (next_op_type == LexTokenType::OP_PLUS || next_op_type == LexTokenType::OP_MINUS || next_op_type == LexTokenType::OP_NOT) {
            LexTokenType unary_operator_token = consume_current_token().type;
            IntermediateOperand sub_expression_operand = parse_unary_level_expression();
            sub_expression_operand = ensure_operand_is_in_register(sub_expression_operand); // Pastikan operand siap

            if (unary_operator_token == LexTokenType::OP_PLUS) {
                return sub_expression_operand; // Unary plus tidak berpengaruh pada nilai
            } else {
                 IntermediateOpCode ir_operation_for_unary = (unary_operator_token == LexTokenType::OP_MINUS) ? IntermediateOpCode::OP_NEGATE : IntermediateOpCode::OP_LOGICAL_NOT;
                 IntermediateOperand unary_result_operand = request_temporary_register();
                 add_ir_instruction(ir_operation_for_unary, sub_expression_operand, IntermediateOperand::create_unspecified(), unary_result_operand);
                 return unary_result_operand;
            }
        } else if (next_op_type == LexTokenType::IDENTIFIER && look_ahead(1).type == LexTokenType::SYM_LPAREN) {
            // Panggilan Fungsi
            return parse_function_call_expression();
        } else {
            // Ekspresi Primer
            return parse_primary_level_expression();
        }
    }

    // <PrimaryExp> ::= '(' <Exp> ')' | <LVal> | <Number>
    IntermediateOperand parse_primary_level_expression() {
        LexTokenType next_prim_type = look_ahead().type;

        if (next_prim_type == LexTokenType::SYM_LPAREN) { // (Exp)
            expect_token_type(LexTokenType::SYM_LPAREN);
            IntermediateOperand encapsulated_expr_result = parse_general_expression();
            expect_token_type(LexTokenType::SYM_RPAREN);
            return encapsulated_expr_result;
        } else if (next_prim_type == LexTokenType::INTEGER_LITERAL) { // Number
            LexToken number_lex_token = expect_token_type(LexTokenType::INTEGER_LITERAL);
            // Kembalikan operand immediate secara langsung. ensure_operand_is_in_register akan memuatnya jika perlu.
            return IntermediateOperand::create_immediate_from_string(number_lex_token.lexeme);
        } else if (next_prim_type == LexTokenType::IDENTIFIER) { // LVal
            // Ini pasti LVal yang digunakan sebagai RValue
            bool is_lval_result_array_base_address = false;
            IntermediateOperand lvalue_address_operand = parse_lvalue_expression(&is_lval_result_array_base_address);

             if (is_lval_result_array_base_address) {
                  // Jika LVal menghasilkan alamat dasar array (misal, `int a[10]; ... x = a;`)
                  // kita perlu memuat *alamat* itu sendiri ke register.
                  if (lvalue_address_operand.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) {
                       IntermediateOperand address_in_register = request_temporary_register();
                       add_ir_instruction(IntermediateOpCode::LOAD_ADDRESS, lvalue_address_operand, IntermediateOperand::create_unspecified(), address_in_register);
                       return address_in_register;
                  } else if (lvalue_address_operand.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) {
                      // Hitung alamat absolut dari offset SP
                      IntermediateOperand address_in_register = request_temporary_register();
                      add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                                         IntermediateOperand::create_mips_reg("$sp"),
                                         IntermediateOperand::create_immediate_from_string(std::to_string(lvalue_address_operand.numeric_value_or_offset)),
                                         address_in_register);
                      return address_in_register;
                  } else {
                       trigger_compilation_error("Internal Error: Unexpected operand type for array base address during primary expression parsing.");
                       return IntermediateOperand::create_unspecified();
                  }
             } else {
                 // Jika LVal menghasilkan alamat skalar atau elemen array tertentu,
                 // muat *nilai* dari alamat itu.
                 // Cek dulu apakah itu konstanta skalar saat kompilasi
                 std::string potential_const_name_check;
                 if (lvalue_address_operand.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) {
                     potential_const_name_check = lvalue_address_operand.representation;
                 }
                 // Untuk alamat lokal/temporer, cek konstanta lebih sulit tanpa nama asli.
                 // Asumsikan hanya skalar global yang dioptimasi cara ini demi kesederhanaan.

                  if (!potential_const_name_check.empty()) {
                     FoundSymbol symbol_lookup_result = search_for_symbol(potential_const_name_check);
                     if (symbol_lookup_result.success && symbol_lookup_result.attributes.is_value_constant && !symbol_lookup_result.attributes.is_array_type()) {
                          // Ini konstanta skalar yang diketahui, kembalikan nilai immediate
                          std::string const_val_str = symbol_lookup_result.attributes.initial_value_representation;
                          if (const_val_str.empty() && !symbol_lookup_result.attributes.constant_array_init_values.empty()) {
                              const_val_str = symbol_lookup_result.attributes.constant_array_init_values[0];
                          }
                          return IntermediateOperand::create_immediate_from_string(const_val_str);
                     }
                  }
                  // Muat nilai dari operand alamat memori
                  return generate_load_from_memory_address(lvalue_address_operand);
             }
        } else {
            trigger_compilation_error("Parser Error: Unexpected token found in primary expression: " + look_ahead().lexeme);
            return IntermediateOperand::create_unspecified(); // Tidak akan tercapai
        }
    }

    // <LVal> ::= Ident {'[' <Exp> ']'}
    // Mengembalikan operand yang merepresentasikan *alamat* dari LVal.
    // Mengatur is_array_base_address menjadi true jika hasilnya adalah alamat dasar (tidak ada kurung siku indeks).
    IntermediateOperand parse_lvalue_expression(bool* is_array_base_address_result) {
        *is_array_base_address_result = false; // Inisialisasi default
        LexToken identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
        FoundSymbol symbol_search_result = search_for_symbol(identifier_token.lexeme);
        if (!symbol_search_result.success) {
             trigger_compilation_error("Semantic Error: Undeclared identifier '" + identifier_token.lexeme + "' used as LValue.");
             return IntermediateOperand::create_unspecified();
        }
        SymbolAttributes symbol_data = symbol_search_result.attributes;

        IntermediateOperand current_effective_address_operand = get_address_operand_for_symbol(symbol_data.identifier_name);
        bool was_array_element_accessed = false; // Lacak apakah kurung siku digunakan

        while (attempt_match_and_consume(LexTokenType::SYM_LBRACKET)) {
             was_array_element_accessed = true;
             IntermediateOperand index_value_operand = parse_general_expression();
             index_value_operand = ensure_operand_is_in_register(index_value_operand); // Indeks harus di register
             expect_token_type(LexTokenType::SYM_RBRACKET);

             // Hitung offset: index * 4 (WORD_SIZE_BYTES)
             IntermediateOperand byte_offset_for_index_reg = request_temporary_register();
             IntermediateOperand element_size_in_bytes_reg = request_temporary_register();
             add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(WORD_SIZE_BYTES), IntermediateOperand::create_unspecified(), element_size_in_bytes_reg);
             add_ir_instruction(IntermediateOpCode::OP_MUL, index_value_operand, element_size_in_bytes_reg, byte_offset_for_index_reg);

             // Hitung alamat elemen: base_address + offset
             // Pastikan alamat dasar ada di register dulu
             IntermediateOperand base_address_in_a_register;
              if (current_effective_address_operand.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) {
                  base_address_in_a_register = request_temporary_register();
                  add_ir_instruction(IntermediateOpCode::LOAD_ADDRESS, current_effective_address_operand, IntermediateOperand::create_unspecified(), base_address_in_a_register);
              } else if (current_effective_address_operand.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) {
                   // Hitung alamat absolut dari offset SP
                   base_address_in_a_register = request_temporary_register();
                   add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_ADDIU,
                                      IntermediateOperand::create_mips_reg("$sp"),
                                      IntermediateOperand::create_immediate_from_string(std::to_string(current_effective_address_operand.numeric_value_or_offset)),
                                      base_address_in_a_register);
              } else if (current_effective_address_operand.type == IntermediateOperand::Type::TEMPORARY_REGISTER || current_effective_address_operand.type == IntermediateOperand::Type::MIPS_HARDWARE_REGISTER){
                  base_address_in_a_register = current_effective_address_operand; // Sudah ada di register (dari dimensi sebelumnya?)
              }
               else {
                   trigger_compilation_error("Internal Error: Invalid base address type encountered during array element access calculation.");
                   return IntermediateOperand::create_unspecified();
               }

             IntermediateOperand calculated_element_address_operand = request_temporary_register();
             add_ir_instruction(IntermediateOpCode::OP_ADD, base_address_in_a_register, byte_offset_for_index_reg, calculated_element_address_operand);
             current_effective_address_operand = calculated_element_address_operand; // Perbarui alamat untuk potensi dimensi berikutnya
        }

        // Tentukan apakah hasil akhirnya adalah alamat dasar atau alamat elemen
         if (symbol_data.is_array_type() && !was_array_element_accessed) {
             *is_array_base_address_result = true;
         }

        return current_effective_address_operand; // Kembalikan operand alamat final
    }

    // Mem-parse Ident '(' [FuncRParams] ')'
    IntermediateOperand parse_function_call_expression() {
        LexToken function_identifier_token = expect_token_type(LexTokenType::IDENTIFIER);
        std::string called_function_name = function_identifier_token.lexeme;
        expect_token_type(LexTokenType::SYM_LPAREN);

        FoundSymbol function_symbol_lookup = search_for_symbol(called_function_name);
        if (!function_symbol_lookup.success || !function_symbol_lookup.attributes.is_function_symbol) {
             trigger_compilation_error("Semantic Error: Call to an undefined or non-function identifier: '" + called_function_name + "'.");
        }
        std::string function_return_data_type = function_symbol_lookup.attributes.data_type_name; // Sebenarnya ini "int" atau "void" dari FuncType

        // --- Passing Argumen ---
        std::vector<IntermediateOperand> evaluated_argument_operands; // Simpan operand yang berisi nilai argumen
        // int spill_state_before_call_args_eval = m_current_spill_area_offset;

        if (look_ahead().type != LexTokenType::SYM_RPAREN) { // Jika ada argumen
            evaluated_argument_operands = parse_actual_function_call_parameters(); // Mengembalikan list operand yang berisi nilai arg
        }
        expect_token_type(LexTokenType::SYM_RPAREN);

        int number_of_arguments = evaluated_argument_operands.size();

        // 1. Lewatkan 4 argumen pertama via register $a0-$a3
        for (int i = 0; i < std::min(4, number_of_arguments); ++i) {
             IntermediateOperand argument_value_op = ensure_operand_is_in_register(evaluated_argument_operands[i]); // Pastikan nilai ada di register
             add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_MOVE, argument_value_op, IntermediateOperand::create_unspecified(), IntermediateOperand::create_mips_reg("$a" + std::to_string(i)));
        }

        // 2. Lewatkan argumen sisa via stack (push dalam urutan terbalik)
         int total_stack_argument_bytes = 0;
         for (int i = number_of_arguments - 1; i >= 4; --i) {
              IntermediateOperand argument_value_op = ensure_operand_is_in_register(evaluated_argument_operands[i]);
              add_ir_instruction(IntermediateOpCode::PUSH_ARGUMENT, argument_value_op);
              total_stack_argument_bytes += WORD_SIZE_BYTES;
         }

        // --- Lakukan Panggilan ---
        add_ir_instruction(IntermediateOpCode::CALL_FUNCTION, IntermediateOperand::create_code_label("FUNC_" + called_function_name));

        // --- Bersihkan Argumen Stack ---
        if (total_stack_argument_bytes > 0) {
            add_ir_instruction(IntermediateOpCode::POP_ARGUMENTS_FROM_STACK, IntermediateOperand::create_immediate(total_stack_argument_bytes));
        }
        // m_current_spill_area_offset = spill_state_before_call_args_eval; // Pelacakan maks lebih aman.

        // --- Tangani Nilai Kembali ---
        if (function_return_data_type != "void") { // Asumsi tipe return disimpan di data_type_name
            IntermediateOperand function_result_register = request_temporary_register();
            // Asumsi hasil ada di $v0, pindahkan ke register temporer
            add_ir_instruction(IntermediateOpCode::MIPS_DIRECT_MOVE, IntermediateOperand::create_mips_reg("$v0"), IntermediateOperand::create_unspecified(), function_result_register);
            return function_result_register;
        } else {
            return IntermediateOperand::create_unspecified(); // Tidak ada nilai kembali
        }
    }

    // <FuncRParams> ::= <Exp> { ',' <Exp> }
    // Mengembalikan list operand yang berisi nilai argumen
    std::vector<IntermediateOperand> parse_actual_function_call_parameters() {
        std::vector<IntermediateOperand> argument_ops_list;
        // Perlu mengevaluasi semua argumen *sebelum* menghasilkan kode setup (seperti memindahkan ke $a0).
        // Evaluasi masing-masing, berpotensi spill hasil antara.

         // Evaluasi argumen pertama
         argument_ops_list.push_back(parse_general_expression());

         // Evaluasi argumen sisa
         while (attempt_match_and_consume(LexTokenType::SYM_COMMA)) {
              argument_ops_list.push_back(parse_general_expression());
         }
        return argument_ops_list;
    }

    // <Cond> ::= <LOrExp>
    IntermediateOperand parse_boolean_condition_expression() {
        IntermediateOperand logical_or_result = parse_logical_or_level_expression();
        // Pastikan hasilnya 0 atau 1 untuk konsistensi dalam kondisi
        logical_or_result = ensure_operand_is_in_register(logical_or_result);
        IntermediateOperand final_condition_value = request_temporary_register();
        // final_condition_value = (logical_or_result != $zero) ? 1 : 0
        add_ir_instruction(IntermediateOpCode::OP_CMP_NOT_EQUAL, logical_or_result, IntermediateOperand::create_mips_reg("$zero"), final_condition_value);
        return final_condition_value;
    }

    // <LOrExp> ::= <LAndExp> { '||' <LAndExp> }
    IntermediateOperand parse_logical_or_level_expression() {
        IntermediateOperand left_operand_result = parse_logical_and_level_expression();

        while (look_ahead().type == LexTokenType::OP_OR) {
            expect_token_type(LexTokenType::OP_OR);
             // Short-circuit untuk ||: jika kiri true (non-zero), hasil true.
             std::string label_if_left_is_true = create_new_unique_label("lor_lhs_true_");
             std::string label_after_or_expression = create_new_unique_label("lor_end_");
             IntermediateOperand final_or_result_reg = request_temporary_register(); // Akan berisi 0 atau 1

             left_operand_result = ensure_operand_is_in_register(left_operand_result); // Perlu branch padanya

             // Jika left_operand_result non-zero (true), lompat untuk set hasil=1 dan lewati sisi kanan
             add_ir_instruction(IntermediateOpCode::BRANCH_IF_NOT_ZERO, left_operand_result, IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_if_left_is_true));

             // Kiri false, evaluasi sisi kanan
             IntermediateOperand right_operand_result = parse_logical_and_level_expression();
             right_operand_result = ensure_operand_is_in_register(right_operand_result);
             // Jika right_operand_result non-zero, hasil adalah 1.
             add_ir_instruction(IntermediateOpCode::BRANCH_IF_NOT_ZERO, right_operand_result, IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_if_left_is_true));

             // Kedua sisi false, hasil adalah 0 (fall through)
             add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(0), IntermediateOperand::create_unspecified(), final_or_result_reg);
             add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_after_or_expression)); // Lompat melewati set true

             // Label untuk set hasil ke 1
             add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_if_left_is_true));
             add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(1), IntermediateOperand::create_unspecified(), final_or_result_reg);

             // Label setelah set hasil (true atau false)
             add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_after_or_expression));

             left_operand_result = final_or_result_reg; // Gunakan hasil untuk || berikutnya
        }
        return left_operand_result; // Hasil akhir mungkin bukan 0/1, akan dinormalisasi oleh parse_boolean_condition_expression
    }

    // <LAndExp> ::= <EqExp> { '&&' <EqExp> }
    IntermediateOperand parse_logical_and_level_expression() {
        IntermediateOperand left_operand_result = parse_equality_level_expression();

         while (look_ahead().type == LexTokenType::OP_AND) {
             expect_token_type(LexTokenType::OP_AND);
              // Short-circuit untuk &&: jika kiri false (zero), hasil false.
              std::string label_if_left_is_false = create_new_unique_label("land_lhs_false_");
              std::string label_after_and_expression = create_new_unique_label("land_end_");
              IntermediateOperand final_and_result_reg = request_temporary_register(); // Akan berisi 0 atau 1

              left_operand_result = ensure_operand_is_in_register(left_operand_result);

              // Jika left_operand_result zero (false), lompat untuk set hasil=0 dan lewati sisi kanan
              add_ir_instruction(IntermediateOpCode::BRANCH_IF_ZERO, left_operand_result, IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_if_left_is_false));

              // Kiri non-zero (true), evaluasi sisi kanan
              IntermediateOperand right_operand_result = parse_equality_level_expression();
              right_operand_result = ensure_operand_is_in_register(right_operand_result);
              // Jika right_operand_result zero, hasil adalah 0.
              add_ir_instruction(IntermediateOpCode::BRANCH_IF_ZERO, right_operand_result, IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_if_left_is_false));

              // Kedua sisi non-zero (true), hasil adalah 1 (fall through)
              add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(1), IntermediateOperand::create_unspecified(), final_and_result_reg);
              add_ir_instruction(IntermediateOpCode::JUMP_UNCONDITIONAL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_after_and_expression)); // Lompat melewati set false

              // Label untuk set hasil ke 0
              add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_if_left_is_false));
              add_ir_instruction(IntermediateOpCode::LOAD_IMMEDIATE, IntermediateOperand::create_immediate(0), IntermediateOperand::create_unspecified(), final_and_result_reg);

              // Label setelah set hasil (true atau false)
              add_ir_instruction(IntermediateOpCode::DEFINE_LABEL, IntermediateOperand::create_unspecified(), IntermediateOperand::create_unspecified(), IntermediateOperand::create_code_label(label_after_and_expression));

              left_operand_result = final_and_result_reg; // Gunakan hasil untuk && berikutnya
         }
        return left_operand_result; // Hasil akhir mungkin bukan 0/1, akan dinormalisasi oleh parse_boolean_condition_expression
    }

    // <EqExp> ::= <RelExp> { ('==' | '!=') <RelExp> }
    IntermediateOperand parse_equality_level_expression() {
        IntermediateOperand left_operand_result = parse_relational_level_expression();

        while (look_ahead().type == LexTokenType::OP_EQUAL || look_ahead().type == LexTokenType::OP_NOT_EQUAL) {
            LexTokenType operation_token_type = consume_current_token().type;
            IntermediateOpCode ir_operation = (operation_token_type == LexTokenType::OP_EQUAL) ? IntermediateOpCode::OP_CMP_EQUAL : IntermediateOpCode::OP_CMP_NOT_EQUAL;

             IntermediateOperand right_operand_result = parse_relational_level_expression();

             left_operand_result = ensure_operand_is_in_register(left_operand_result);
             right_operand_result = ensure_operand_is_in_register(right_operand_result);

            IntermediateOperand comparison_result_operand = request_temporary_register();
            add_ir_instruction(ir_operation, left_operand_result, right_operand_result, comparison_result_operand); // EQL/NEQ hasil 0 atau 1
            left_operand_result = comparison_result_operand;
        }
        return left_operand_result;
    }

    // <RelExp> ::= <AddExp> { ('<' | '>' | '<=' | '>=') <AddExp> }
    IntermediateOperand parse_relational_level_expression() {
        IntermediateOperand left_operand_result = parse_additive_level_expression();

        while (look_ahead().type == LexTokenType::OP_LESS || look_ahead().type == LexTokenType::OP_GREATER ||
               look_ahead().type == LexTokenType::OP_LESS_EQUAL || look_ahead().type == LexTokenType::OP_GREATER_EQUAL)
        {
            LexTokenType operation_token_type = consume_current_token().type;
            IntermediateOpCode ir_operation;
            if (operation_token_type == LexTokenType::OP_LESS) ir_operation = IntermediateOpCode::OP_CMP_LESS;
            else if (operation_token_type == LexTokenType::OP_GREATER) ir_operation = IntermediateOpCode::OP_CMP_GREATER;
            else if (operation_token_type == LexTokenType::OP_LESS_EQUAL) ir_operation = IntermediateOpCode::OP_CMP_LESS_EQUAL;
            else ir_operation = IntermediateOpCode::OP_CMP_GREATER_EQUAL; // GEQ

            IntermediateOperand right_operand_result = parse_additive_level_expression();

            left_operand_result = ensure_operand_is_in_register(left_operand_result);
            right_operand_result = ensure_operand_is_in_register(right_operand_result);

            IntermediateOperand comparison_result_operand = request_temporary_register();
            add_ir_instruction(ir_operation, left_operand_result, right_operand_result, comparison_result_operand); // Operasi relasional hasil 0 atau 1
            left_operand_result = comparison_result_operand;
        }
        return left_operand_result;
    }


    // --- MIPS Generation Logic ---
    std::string mips_operand_string(const IntermediateOperand& operand_info) {
        if (operand_info.representation.empty() &&
            operand_info.type != IntermediateOperand::Type::UNSPECIFIED && // UNUSED bisa kosong
            operand_info.type != IntermediateOperand::Type::IMMEDIATE_VALUE ) { // Immediate 0 bisa punya rep kosong jika dibuat default
             // trigger_compilation_error("MIPS operand generation: Critical empty representation for a significant operand type.");
             // Untuk label atau register, representasi kosong itu fatal.
             // Untuk immediate, jika nilainya 0, representasinya bisa "0".
             if(operand_info.type == IntermediateOperand::Type::IMMEDIATE_VALUE && operand_info.numeric_value_or_offset == 0) return "0";

        }

        switch (operand_info.type) {
            case IntermediateOperand::Type::UNSPECIFIED:            return ""; // Untuk argumen IR yang tidak digunakan
            case IntermediateOperand::Type::TEMPORARY_REGISTER:     return "$" + operand_info.representation; // misal $t0
            case IntermediateOperand::Type::MIPS_HARDWARE_REGISTER: return operand_info.representation;       // misal $sp, $ra
            case IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL:  return operand_info.representation;       // Nama var global (sbg label)
            case IntermediateOperand::Type::STACK_LOCAL_ADDRESS:    return operand_info.representation;       // Format "offset($sp)"
            case IntermediateOperand::Type::IMMEDIATE_VALUE:        return operand_info.representation;       // Nilai immediate numerik
            case IntermediateOperand::Type::CODE_LABEL:             return operand_info.representation;       // Nama label (L_1, FUNC_main)
            case IntermediateOperand::Type::STRING_DATA_LABEL:      return operand_info.representation;       // Label string (s_data_0)
            default:
                trigger_compilation_error("MIPS operand generation: Encountered an unknown operand type.");
                return "<UNKNOWN_OPERAND>";
        }
    }

    void translate_ir_to_mips(std::ostream& output_mips_stream) {
        // --- Segmen Data ---
        output_mips_stream << ".data\n";
        // Deklarasi variabel global (berdasarkan scope global di tabel simbol)
        if (!m_symbol_table_manager.empty()) {
            const auto& global_symbol_scope = m_symbol_table_manager[0];
            for (SymbolTableScope::const_iterator iter = global_symbol_scope.begin(); iter != global_symbol_scope.end(); ++iter) {
                 const SymbolAttributes& symbol_attrs = iter->second;
                 // Lewati fungsi dan simbol non-global (seharusnya tidak ada di scope global)
                 if (symbol_attrs.is_function_symbol || !symbol_attrs.is_globally_scoped) continue;

                 output_mips_stream << symbol_attrs.identifier_name << ": ";
                 if (symbol_attrs.is_value_constant) {
                     output_mips_stream << ".word ";
                     if (!symbol_attrs.constant_array_init_values.empty()) {
                          for (size_t i = 0; i < symbol_attrs.constant_array_init_values.size(); ++i) {
                              output_mips_stream << symbol_attrs.constant_array_init_values[i]
                                           << (i == symbol_attrs.constant_array_init_values.size() - 1 ? "" : ", ");
                          }
                     } else if (!symbol_attrs.initial_value_representation.empty()) { // Seharusnya skalar
                          output_mips_stream << symbol_attrs.initial_value_representation;
                     } else {
                          output_mips_stream << "0"; // Default jika nilai entah bagaimana hilang
                     }
                     output_mips_stream << "\n";
                 } else { // Variabel global non-konstanta
                      if (symbol_attrs.is_array_type()) {
                           if (!symbol_attrs.initial_value_representation.empty() && symbol_attrs.initial_value_representation.at(0) == '{') {
                                // Array global yang diinisialisasi, parse {v1,v2...}
                                std::string values_str = symbol_attrs.initial_value_representation.substr(1, symbol_attrs.initial_value_representation.length() - 2);
                                if (values_str.empty() && symbol_attrs.num_array_elements > 0) { // Kasus {.space} dari init default
                                      output_mips_stream << ".space " << symbol_attrs.num_array_elements * WORD_SIZE_BYTES << "\n";
                                } else if (!values_str.empty()) {
                                      output_mips_stream << ".word " << values_str << "\n"; // Asumsi values_str adalah "v1,v2,..."
                                } else { // Tidak ada nilai, tapi bukan array kosong
                                     output_mips_stream << ".space " << symbol_attrs.num_array_elements * WORD_SIZE_BYTES << "\n";
                                }
                           } else { // Array global tidak diinisialisasi atau diinisialisasi default
                                output_mips_stream << ".space " << symbol_attrs.num_array_elements * WORD_SIZE_BYTES << "\n";
                           }
                      } else { // Variabel global skalar
                           std::string initial_val_str = symbol_attrs.initial_value_representation.empty() ? "0" : symbol_attrs.initial_value_representation;
                           output_mips_stream << ".word " << initial_val_str << "\n";
                      }
                 }
            }
        }
        // Literal String
        for (size_t i = 0; i < m_data_segment_literals.size(); ++i) {
            output_mips_stream << m_data_segment_literals[i].first << ": .asciiz " << m_data_segment_literals[i].second << "\n";
        }

        // --- Segmen Teks ---
        output_mips_stream << ".text\n";
        output_mips_stream << ".globl main\n"; // Pastikan main terlihat secara global

        // --- Wrapper Entri Main (jika diperlukan, misal, setup stack) ---
        output_mips_stream << "main:\n";
        output_mips_stream << "    li   $sp, 0x7ffffffc\n"; // Inisialisasi stack pointer
        output_mips_stream << "    jal  FUNC_main\n";        // Lompat ke main yang dikompilasi sebenarnya
        output_mips_stream << "    li   $v0, 10\n";          // Kode syscall exit
        output_mips_stream << "    syscall\n\n";             // Akhiri program (baris kosong ekstra)


        // --- Terjemahkan Instruksi IR ---
        for (size_t i = 0; i < m_ir_code_sequence.size(); ++i) {
             const IntermediateInstruction& current_ir_instr = m_ir_code_sequence[i];
             std::string op1_mips_str = mips_operand_string(current_ir_instr.arg1);
             std::string op2_mips_str = mips_operand_string(current_ir_instr.arg2);
             std::string result_tgt_mips_str = mips_operand_string(current_ir_instr.result_or_target);

             switch (current_ir_instr.operation) {
                 // Aritmatika & Logika
                 case IntermediateOpCode::OP_ADD: output_mips_stream << "    add  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_SUB: output_mips_stream << "    sub  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_MUL: output_mips_stream << "    mult " << op1_mips_str << ", " << op2_mips_str << "\n" << "    mflo " << result_tgt_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_DIV: output_mips_stream << "    div  " << op1_mips_str << ", " << op2_mips_str << "\n" << "    mflo " << result_tgt_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_MOD: output_mips_stream << "    div  " << op1_mips_str << ", " << op2_mips_str << "\n" << "    mfhi " << result_tgt_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_NEGATE: output_mips_stream << "    sub  " << result_tgt_mips_str << ", $zero, " << op1_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_LOGICAL_NOT: output_mips_stream << "    sltiu " << result_tgt_mips_str << ", " << op1_mips_str << ", 1\n"; break; // !x -> x < 1 (hasil 0 atau 1)
                 case IntermediateOpCode::OP_LOGICAL_AND: output_mips_stream << "    and  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break; // Asumsi hasil 0/1 dari parser
                 case IntermediateOpCode::OP_LOGICAL_OR:  output_mips_stream << "    or   " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break; // Asumsi hasil 0/1 dari parser

                 // Perbandingan (hasil adalah 0 atau 1)
                 case IntermediateOpCode::OP_CMP_LESS: output_mips_stream << "    slt  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_CMP_LESS_EQUAL: output_mips_stream << "    sle  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_CMP_GREATER: output_mips_stream << "    sgt  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_CMP_GREATER_EQUAL: output_mips_stream << "    sge  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_CMP_EQUAL: output_mips_stream << "    seq  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;
                 case IntermediateOpCode::OP_CMP_NOT_EQUAL: output_mips_stream << "    sne  " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;

                 // Memori
                 case IntermediateOpCode::LOAD_IMMEDIATE: output_mips_stream << "    li   " << result_tgt_mips_str << ", " << op1_mips_str << "\n"; break;
                 case IntermediateOpCode::LOAD_ADDRESS: output_mips_stream << "    la   " << result_tgt_mips_str << ", " << op1_mips_str << "\n"; break;
                 case IntermediateOpCode::LOAD_FROM_MEMORY: // lw dest_reg(result_tgt), address_operand(op1)
                     if (current_ir_instr.arg1.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) { output_mips_stream << "    la   " << MIPS_HELPER_REG_1 << ", " << op1_mips_str << "\n" << "    lw   " << result_tgt_mips_str << ", 0(" << MIPS_HELPER_REG_1 << ")\n"; }
                     else if (current_ir_instr.arg1.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) { output_mips_stream << "    lw   " << result_tgt_mips_str << ", " << op1_mips_str << "\n"; } // op1 sudah format "offset($sp)"
                     else if (current_ir_instr.arg1.type == IntermediateOperand::Type::TEMPORARY_REGISTER || current_ir_instr.arg1.type == IntermediateOperand::Type::MIPS_HARDWARE_REGISTER) { output_mips_stream << "    lw   " << result_tgt_mips_str << ", 0(" << op1_mips_str << ")\n"; } // Alamat ada di register op1
                     else trigger_compilation_error("MIPS Gen Error: Invalid address operand for LOAD_FROM_MEMORY: " + op1_mips_str); break;
                 case IntermediateOpCode::STORE_TO_MEMORY: // sw value_reg(op1), address_operand(result_tgt)
                     if (current_ir_instr.result_or_target.type == IntermediateOperand::Type::GLOBAL_VARIABLE_LABEL) { output_mips_stream << "    la   " << MIPS_HELPER_REG_1 << ", " << result_tgt_mips_str << "\n" << "    sw   " << op1_mips_str << ", 0(" << MIPS_HELPER_REG_1 << ")\n"; }
                     else if (current_ir_instr.result_or_target.type == IntermediateOperand::Type::STACK_LOCAL_ADDRESS) { output_mips_stream << "    sw   " << op1_mips_str << ", " << result_tgt_mips_str << "\n"; } // result_tgt sudah format "offset($sp)"
                     else if (current_ir_instr.result_or_target.type == IntermediateOperand::Type::TEMPORARY_REGISTER || current_ir_instr.result_or_target.type == IntermediateOperand::Type::MIPS_HARDWARE_REGISTER) { output_mips_stream << "    sw   " << op1_mips_str << ", 0(" << result_tgt_mips_str << ")\n"; } // Alamat ada di register result_tgt
                     else trigger_compilation_error("MIPS Gen Error: Invalid address operand for STORE_TO_MEMORY: " + result_tgt_mips_str); break;

                 // Aliran Kontrol
                 case IntermediateOpCode::DEFINE_LABEL: if(result_tgt_mips_str.empty()) trigger_compilation_error("MIPS Gen Error: Attempting to define an empty label."); output_mips_stream << result_tgt_mips_str << ":\n"; break; // result_or_target adalah label
                 case IntermediateOpCode::JUMP_UNCONDITIONAL: if(result_tgt_mips_str.empty()) trigger_compilation_error("MIPS Gen Error: Attempting to jump to an empty label."); output_mips_stream << "    j    " << result_tgt_mips_str << "\n"; break; // result_or_target adalah label
                 case IntermediateOpCode::BRANCH_IF_EQUAL: output_mips_stream << "    beq  " << op1_mips_str << ", " << op2_mips_str << ", " << result_tgt_mips_str << "\n"; break; // result_or_target adalah label
                 case IntermediateOpCode::BRANCH_IF_NOT_EQUAL: output_mips_stream << "    bne  " << op1_mips_str << ", " << op2_mips_str << ", " << result_tgt_mips_str << "\n"; break; // result_or_target adalah label
                 case IntermediateOpCode::BRANCH_IF_ZERO: if(op1_mips_str == "0") trigger_compilation_error("MIPS Gen Error: Cannot branch on immediate 0, use $zero register."); output_mips_stream << "    beq  " << op1_mips_str << ", $zero, " << result_tgt_mips_str << "\n"; break; // op2 implisit $zero, result_or_target adalah label
                 case IntermediateOpCode::BRANCH_IF_NOT_ZERO: if(op1_mips_str == "0") trigger_compilation_error("MIPS Gen Error: Cannot branch on immediate 0, use $zero register."); output_mips_stream << "    bne  " << op1_mips_str << ", $zero, " << result_tgt_mips_str << "\n"; break; // op2 implisit $zero, result_or_target adalah label
                 case IntermediateOpCode::JUMP_TO_REGISTER: output_mips_stream << "    jr   " << op1_mips_str << "\n"; break; // op1 adalah register ($ra)

                 // Panggilan & Pengembalian Fungsi
                 case IntermediateOpCode::CALL_FUNCTION: output_mips_stream << "    jal  " << op1_mips_str << "\n"; break; // op1 adalah label fungsi
                 case IntermediateOpCode::RETURN_VALUE: output_mips_stream << "    move $v0, " << op1_mips_str << "\n"; break; // Nilai kembali ada di op1. Jump ke epilogue ditangani parser.
                 case IntermediateOpCode::RETURN_VOID: break; // Tidak ada nilai. Jump ke epilogue ditangani parser.
                 case IntermediateOpCode::PUSH_ARGUMENT: output_mips_stream << "    addiu $sp, $sp, -4\n" << "    sw   " << op1_mips_str << ", 0($sp)\n"; break; // op1 adalah nilai argumen
                 case IntermediateOpCode::POP_ARGUMENTS_FROM_STACK: output_mips_stream << "    addiu $sp, $sp, " << op1_mips_str << "\n"; break; // op1 adalah jumlah byte (immediate)

                 // Input/Output
                 case IntermediateOpCode::SYSTEM_GETINT: output_mips_stream << "    li   $v0, 5\n" << "    syscall\n" << "    move " << result_tgt_mips_str << ", $v0\n"; break; // hasil ke result_tgt
                 case IntermediateOpCode::SYSTEM_PRINT_STRING: output_mips_stream << "    li   $v0, 4\n" << "    la   $a0, " << op1_mips_str << "\n" << "    syscall\n"; break; // op1 adalah label string
                 case IntermediateOpCode::SYSTEM_PRINT_INT: output_mips_stream << "    li   $v0, 1\n" << "    move $a0, " << op1_mips_str << "\n" << "    syscall\n"; break; // op1 adalah nilai integer

                 // Pembantu khusus MIPS (Operand disesuaikan dengan IR yang dihasilkan parser Anda)
                 // Asumsi: MIPS_DIRECT_LW op1=dest_reg, op2=addr_operand | MIPS_DIRECT_SW op1=src_reg, op2=addr_operand
                 case IntermediateOpCode::MIPS_DIRECT_LW: // op1=dest_reg, op2=address
                     if (current_ir_instr.arg2.type == IntermediateOperand::Type::TEMPORARY_REGISTER || current_ir_instr.arg2.type == IntermediateOperand::Type::MIPS_HARDWARE_REGISTER) { output_mips_stream << "    lw   " << op1_mips_str << ", 0(" << op2_mips_str << ")\n"; } // Alamat di register op2
                     else { output_mips_stream << "    lw   " << op1_mips_str << ", " << op2_mips_str << "\n"; } // Asumsi op2 adalah "offset($reg)" atau label
                     break;
                 case IntermediateOpCode::MIPS_DIRECT_SW: // op1=src_reg, op2=address
                     if (current_ir_instr.arg2.type == IntermediateOperand::Type::TEMPORARY_REGISTER || current_ir_instr.arg2.type == IntermediateOperand::Type::MIPS_HARDWARE_REGISTER) { output_mips_stream << "    sw   " << op1_mips_str << ", 0(" << op2_mips_str << ")\n"; } // Alamat di register op2
                     else { output_mips_stream << "    sw   " << op1_mips_str << ", " << op2_mips_str << "\n"; } // Asumsi op2 adalah "offset($reg)" atau label
                     break;

                 case IntermediateOpCode::MIPS_DIRECT_MOVE: output_mips_stream << "    move " << result_tgt_mips_str << ", " << op1_mips_str << "\n"; break;
                 case IntermediateOpCode::MIPS_DIRECT_SYSCALL: output_mips_stream << "    syscall\n"; break;
                 case IntermediateOpCode::MIPS_DIRECT_LOAD_ADDRESS: output_mips_stream << "    la   " << result_tgt_mips_str << ", " << op1_mips_str << "\n"; break;
                 case IntermediateOpCode::MIPS_DIRECT_ADDIU: output_mips_stream << "    addiu " << result_tgt_mips_str << ", " << op1_mips_str << ", " << op2_mips_str << "\n"; break;


                 case IntermediateOpCode::NO_OPERATION: /* Jangan output apa pun untuk NOP */ break;
                 case IntermediateOpCode::FUNCTION_PROLOGUE_MARKER: /* Ditangani oleh logika prologue */ break;
                 case IntermediateOpCode::FUNCTION_EPILOGUE_MARKER: /* Ditangani oleh logika epilogue */ break;
                 default:
                     trigger_compilation_error("MIPS Gen Error: Encountered an unsupported IR operation code during MIPS generation.");
                     output_mips_stream << "    # ERROR: Unsupported IR Opcode: " << static_cast<int>(current_ir_instr.operation) << "\n";
                     break;
             }
        }
    }

}; // Akhir kelas SysYCompiler


// --- Logika Eksekusi Utama ---

int main() {
    std::ifstream source_file_stream("testfile.txt");
    if (!source_file_stream.is_open()) {
        std::cerr << "Fatal Error: Unable to open source file 'testfile.txt'." << std::endl;
        return 1; // Indikasi error
    }
    std::stringstream source_buffer;
    source_buffer << source_file_stream.rdbuf();
    source_file_stream.close();
    std::string input_source_code = source_buffer.str();

    std::ofstream mips_output_file_stream("mips.txt");
    if (!mips_output_file_stream.is_open()) {
        std::cerr << "Fatal Error: Unable to open 'mips.txt' for writing MIPS code." << std::endl;
        return 1; // Indikasi error
    }

    SysYCompiler main_compiler_instance;
    bool compilation_was_successful = main_compiler_instance.process_source(input_source_code, mips_output_file_stream);
    mips_output_file_stream.close(); // Tutup file output mips

    if (!compilation_was_successful) {
        // Pesan error detail sudah dicetak ke std::cerr oleh Compiler
        return 1; // Indikasi kegagalan kompilasi
    }

    // Untuk Online Judge, biasanya tidak ada output sukses ke stdout dari compiler
    // std::cout << "Compilation finished successfully. MIPS assembly code is in mips.txt." << std::endl;

    // Bagian pemanggilan MARS dihapus karena Online Judge akan menanganinya
    return 0; // Indikasi sukses
}